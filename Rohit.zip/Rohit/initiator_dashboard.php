<?php
session_start();
include ('include/connection.php');

// Check if session variables exist
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'Initiator') {
    header("Location: index.php");
    exit();
}

$id = $_SESSION['id'];
$name = $_SESSION['name'] ?? 'User';

// Function to fetch counts securely
function fetch_count($conn, $query, $param = null)
{
    $stmt = $conn->prepare($query);
    
    if (!$stmt) {
        die("Query Preparation Failed: " . $conn->error);
    }

    if ($param !== null) {
        $stmt->bind_param("i", $param);
    }

    $stmt->execute();
    // $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    return $count ?? 0;
}

// Visitor request statistics for the logged-in Initiator
$total_requests = fetch_count($conn, "SELECT COUNT(*) FROM tbl_visitors WHERE id = ?", $id);
$pending_requests = fetch_count($conn, "SELECT COUNT(*) FROM tbl_visitors WHERE id = ? AND status = 'Pending'", $id);
$approved_requests = fetch_count($conn, "SELECT COUNT(*) FROM tbl_visitors WHERE id = ? AND status = 'Approved'", $id);
$rejected_requests = fetch_count($conn, "SELECT COUNT(*) FROM tbl_visitors WHERE id = ? AND status = 'Rejected'", $id);

?>

<?php include('include/header.php'); ?>

<div id="wrapper">
    <?php include('include/ini_side.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">

            <!-- Breadcrumbs -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            </ol>
            <h3>Welcome, <?= htmlspecialchars($name); ?></h3>

            <div class="row">
                <?php 
                // Dashboard widgets data
                $widgets = [
                    ["title" => "Total Requests", "count" => $total_requests, "icon" => "fa-file-alt", "bg" => "bg-secondary"],
                    ["title" => "Pending Requests", "count" => $pending_requests, "icon" => "fa-clock", "bg" => "bg-warning"],
                    ["title" => "Approved Requests", "count" => $approved_requests, "icon" => "fa-check-circle", "bg" => "bg-success"],
                    ["title" => "Rejected Requests", "count" => $rejected_requests, "icon" => "fa-times-circle", "bg" => "bg-danger"]
                ];

                foreach ($widgets as $widget) : ?>
                <div class="col-sm-3">
                    <section class="panel panel-featured-left panel-featured-primary">
                        <div class="panel-body">
                            <div class="widget-summary">
                                <div class="widget-summary-col widget-summary-col-icon">
                                    <div class="summary-icon <?= $widget['bg']; ?>">
                                        <i class="fa <?= $widget['icon']; ?>"></i>
                                    </div>
                                </div>
                                <div class="widget-summary-col">
                                    <div class="summary">
                                        <h4 class="title"><?= $widget['title']; ?></h4>
                                        <div class="info">
                                            <strong class="amount"><?= $widget['count']; ?></strong>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="mt-4">
                <a href="add_visitor.php" class="btn btn-primary">Create New Visitor Request</a>
            </div>

        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top"><i class="fas fa-angle-up"></i></a>

<?php include('include/footer.php'); ?>
