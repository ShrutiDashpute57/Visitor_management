<?php
session_start();
include 'include/connection.php';

if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

// Accept or Reject visitor
if (isset($_GET['action']) && isset($_GET['id'])) {
    $visitor_id = mysqli_real_escape_string($conn, $_GET['id']);
    $status = ($_GET['action'] == "accept") ? 1 : 2; // 1 = Accepted, 2 = Rejected

    $updateQuery = "UPDATE tbl_visitors SET status='$status' WHERE id='$visitor_id'";
    mysqli_query($conn, $updateQuery);
    header("Location: manage-visitors.php");
    exit();
}

// Delete visitor
if (isset($_GET['delete_id'])) {
    $visitor_id = mysqli_real_escape_string($conn, $_GET['delete_id']);
    mysqli_query($conn, "DELETE FROM tbl_visitors WHERE id='$visitor_id'");
    header("Location: manage-visitors.php");
    exit();
}

?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Manage Visitors</a>
                </li>
            </ol>

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-info-circle"></i> Visitors List
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Visitor Name</th>
                                    <th>Department</th>
                                    <th>Contact Person</th>
                                    <th>Firm Name</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT * FROM tbl_visitors ORDER BY id DESC";
                                $result = mysqli_query($conn, $query);
                                $sn = 1;

                                while ($row = mysqli_fetch_assoc($result)) {
                                    $statusText = "<span class='badge badge-warning'>Pending</span>"; // Default
                                    if ($row['status'] == 1) {
                                        $statusText = "<span class='badge badge-success'>Accepted</span>";
                                    } elseif ($row['status'] == 2) {
                                        $statusText = "<span class='badge badge-danger'>Rejected</span>";
                                    }

                                    echo "<tr>
                                        <td>{$sn}</td>
                                        <td>" . htmlspecialchars($row['visitor_name'] ?? 'N/A') . "</td>
                                        <td>" . htmlspecialchars($row['department'] ?? 'N/A') . "</td>
                                        <td>" . htmlspecialchars($row['contact_person_name'] ?? 'N/A') . "</td>
                                        <td>" . htmlspecialchars($row['firm_name_address'] ?? 'N/A') . "</td>
                                        <td>$statusText</td>
                                        <td>
                                            <a href='edit-visitor.php?id={$row['id']}' class='btn btn-info btn-sm'><i class='fa fa-pencil'></i> Edit</a>
                                            <a href='manage-visitors.php?delete_id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirmDelete()'><i class='fa fa-trash'></i> Delete</a>";

                                    if ($row['status'] == 0) { // Show Accept/Reject if status is pending
                                        echo " 
                                            <a href='manage-visitors.php?action=accept&id={$row['id']}' class='btn btn-success btn-sm'><i class='fa fa-check'></i> Accept</a>
                                            <a href='manage-visitors.php?action=reject&id={$row['id']}' class='btn btn-danger btn-sm'><i class='fa fa-times'></i> Reject</a>";
                                    } elseif ($row['status'] == 1) { // If accepted, show download button
                                        echo " 
                                            <a href='download.php?id={$row['id']}' class='btn btn-primary btn-sm'><i class='fa fa-download'></i> Download Form</a>";
                                    }

                                    echo "</td></tr>";
                                    $sn++;
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>

<script>
function confirmDelete() {
    return confirm('Are you sure you want to delete this Visitor?');
}
</script>
