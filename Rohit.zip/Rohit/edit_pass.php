<?php
session_start();
include 'include/connection.php';

if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

// Validate pass_no (ensure it's passed as GET parameter)
$pass_no = isset($_GET['pass_no']) ? $_GET['pass_no'] : (isset($_GET['id']) ? $_GET['id'] : '');

if (empty($pass_no)) {
    echo "<script>alert('No valid pass selected.'); window.location='manage_pass.php';</script>";
    exit();
}

// Fetch the pass details
$query = "SELECT * FROM tbl_pass WHERE pass_no = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $pass_no);
$stmt->execute();
$result = $stmt->get_result();
$pass = $result->fetch_assoc();
$stmt->close();

if (!$pass) {
    echo "<script>alert('Invalid pass number.'); window.location='manage_pass.php';</script>";
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update-pass'])) {
    $name = trim($_POST['name']);
    $designation = trim($_POST['designation']);
    $department = trim($_POST['department']);
    $purpose = trim($_POST['purpose']);
    $initiating_officer = trim($_POST['initiating_officer']);
    $status = intval($_POST['status']);

    // Validate required fields
    if (empty($name) || empty($designation) || empty($department) || empty($purpose) || empty($initiating_officer)) {
        echo "<script>alert('All fields are required.');</script>";
    } else {
        // Prepare the UPDATE query
        $query = "UPDATE tbl_pass SET name=?, designation=?, department=?, purpose=?, initiating_officer=?, status=? WHERE pass_no=?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssssis", $name, $designation, $department, $purpose, $initiating_officer, $status, $pass_no);

        if ($stmt->execute()) {
            echo "<script>alert('Pass details updated successfully.'); window.location='manage_pass.php';</script>";
        } else {
            echo "<script>alert('Error updating record: " . $stmt->error . "');</script>";
        }
        $stmt->close();
    }
}

?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Edit Out Pass</a></li>
            </ol>
            <div class="card mb-3">
                <div class="card-header"><i class="fa fa-edit"></i> Update Out Pass Details</div>
                <form method="post" class="form-valide">
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Pass No:</label>
                            <div class="col-lg-6">
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($pass['pass_no']); ?>" readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Name:</label>
                            <div class="col-lg-6">
                                <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($pass['name']); ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Designation:</label>
                            <div class="col-lg-6">
                                <input type="text" name="designation" class="form-control" value="<?php echo htmlspecialchars($pass['designation']); ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Department <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <select name="department" class="form-control" required>
                                    <option value="">Select Department</option>
                                    <?php
                                    $select_department = mysqli_query($conn, "SELECT * FROM tbl_department WHERE status=1");
                                    while ($dept = mysqli_fetch_array($select_department)) {
                                        $selected = ($dept['department'] == $pass['department']) ? "selected" : "";
                                        echo "<option value='".$dept['department']."' $selected>".$dept['department']."</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Purpose:</label>
                            <div class="col-lg-6">
                                <input type="text" name="purpose" class="form-control" value="<?php echo htmlspecialchars($pass['purpose']); ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Initiating Officer:</label>
                            <div class="col-lg-6">
                                <input type="text" name="initiating_officer" class="form-control" value="<?php echo htmlspecialchars($pass['initiating_officer']); ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Status:</label>
                            <div class="col-lg-6">
                                <select name="status" class="form-control" required>
                                    <option value="0" <?php echo ($pass['status'] == 0) ? 'selected' : ''; ?>>Pending</option>
                                    <option value="1" <?php echo ($pass['status'] == 1) ? 'selected' : ''; ?>>Accepted</option>
                                    <option value="2" <?php echo ($pass['status'] == 2) ? 'selected' : ''; ?>>Rejected</option>
                                </select>
                            </div>
                        </div>
                        <button type="submit" name="update-pass" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include('include/footer.php'); ?>
