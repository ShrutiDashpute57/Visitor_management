<?php
session_start();
include 'include/connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $designation = $_POST['designation'];
    $date = $_POST['date'];
    $purpose = $_POST['purpose'];
    $department = $_POST['department'];
    $initiating_officer = $_POST['initiating_officer'];
    $officer_designation = $_POST['officer_designation'];
    $out_time = $_POST['out_time'];

    // ✅ Generate a unique Pass Number (Example: PASS-1001)
    $pass_no = "PASS-" . rand(1000, 9999);

    // ✅ Insert Data into tbl_pass (Including pass_no, created_at, and status)
    $sql = "INSERT INTO tbl_pass (pass_no, name, designation, date, purpose, department, initiating_officer, officer_designation, out_time, created_at, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), 0)";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("❌ SQL Error: " . $conn->error); // Debugging
    }

    $stmt->bind_param("sssssssss", $pass_no, $name, $designation, $date, $purpose, $department, $initiating_officer, $officer_designation, $out_time);

    if ($stmt->execute()) {
        echo "<script>alert('✅ Pass request submitted successfully!'); window.location.href='manage_pass.php';</script>";
    } else {
        echo "<script>alert('❌ Error: " . $stmt->error . "'); window.history.back();</script>";
    }

    $stmt->close();
}
?>


<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Create Out Pass</a></li>
            </ol>
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-ticket"></i> Out Pass Form
                </div>
                <form method="post">
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Name <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="name" class="form-control" placeholder="Enter Name" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Designation <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="designation" class="form-control" placeholder="Enter Designation" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Date <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="date" name="date" class="form-control" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Purpose <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="purpose" class="form-control"  placeholder="Enter Purpose"   required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Department <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <select name="department" class="form-control" required>
                                    <option value="">Select Department</option>
                                    <?php
                                    $stmt = $conn->prepare("SELECT department FROM tbl_department WHERE status=1");
                                    $stmt->execute();
                                    $result = $stmt->get_result();
                                    while ($dept = $result->fetch_assoc()) {
                                        echo "<option value='".$dept['department']."'>".$dept['department']."</option>";
                                    }
                                    $stmt->close();
                                    ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Name of Initiating Officer <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="initiating_officer" class="form-control"  placeholder="Enter Name"  required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Officer's Designation <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="officer_designation" class="form-control" placeholder="Enter Designation" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Out Time <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="time" name="out_time" class="form-control" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-lg-8 ml-auto">
                                <button type="submit" class="btn btn-primary">Submit Pass Request</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include('include/footer.php'); ?>
