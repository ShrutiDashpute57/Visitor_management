<?php
session_start();
require 'vendor/autoload.php';
include 'include/connection.php';

use Dompdf\Dompdf;
use Dompdf\Options;

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Invalid request. No ID provided.");
}

$visitor_id = mysqli_real_escape_string($conn, $_GET['id']);

// Fetch visitor details from database
$query = "SELECT * FROM tbl_visitors WHERE id = '$visitor_id'";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    die("Visitor not found.");
}

$row = mysqli_fetch_assoc($result);

// Check if 'purpose_visit' field exists
if (!isset($row['purpose_visit'])) {
    die("Error: Purpose of Visit field not found in the database.");
}

// Dompdf Options
$options = new Options();
$options->set('defaultFont', 'Arial');
$options->set('isHtml5ParserEnabled', true);

$dompdf = new Dompdf($options);

// HTML Content for PDF
$html = "
<style>
    body { font-family: Arial, sans-serif; margin: 30px; font-size: 14px; }
    h2 { text-align: center; text-decoration: underline; }
    p1 { text-align: center; font-size: 12px; font-style: italic; }
     p{ text-align: left; font-size: 12px; font-style: italic; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    td { padding: 8px; border: 1px solid #000; }
    .bold { font-weight: bold; }
    .section-title { text-decoration: underline; font-weight: bold; text-align:center; }
    .signature { margin-top: 20px; }
</style>

<h2>REQUISITION FOR ENTRY OF VISITOR TO ACEM</h2>
<p1>(Note: Intimation of visit to be given to Security Division 24 Hours in advance)</p1>

<table>
    <tr><td class='bold'>1. Name of Division & Escort Person:</td><td>{$row['department']} / {$row['escort_person']}</td></tr>
    <tr><td class='bold'>2. Name & Tel No. of Contact Person:</td><td>{$row['contact_person_name']} / {$row['contact_person_tel']}</td></tr>
    <tr><td class='bold'>3. Name of Visitor:</td><td>{$row['visitor_name']}</td></tr>
    <tr><td class='bold'>4. Visitor Aadhar Card No. & Vehicle No.:</td><td>{$row['visitor_aadhar']} / {$row['visitor_vehicle']}</td></tr>
    <tr><td class='bold'>5. Name of Firm with Address & Tel No.:</td><td>{$row['firm_name_address']}</td></tr>
    <tr><td class='bold'>6. Purpose of Visit:</td><td>{$row['purpose_visit']}</td></tr>
    <tr><td class='bold'>7. Date & Time of Arrival:</td><td>{$row['arrival_datetime']}</td></tr>
    <tr><td class='bold'>8. Area/Facility to be visited:</td><td>{$row['area_facility']}</td></tr>
    <tr><td class='bold'>9. Remarks (if any):</td><td>______________________</td></tr>
</table>

<p1><b>Note:</b> The concerned division takes full responsibility for visitor movement inside ACEM complex and no visitor is allowed without original ID proof and driving license.</p1>

<br>
<br>
<div class='signature'>
    <p class='bold'>Initiated by:</p>
    <p>Name & Designation: ______________________</p>
    <p>Signature: ______________________ </p>
           <p> (*not below Class 1 Officer)</p>
</div>

<br>
<br>
<h3 class='section-title'>Approved / Not Approved</h3>


<br>
<br>
<div class='signature'>
    <p>Counter Signature by JD/HOD: ______________________</p>
    <br>
    <br>
    <p1>Perused by Security Division</p1>
</div>

<table>
    <tr><td class='bold'>Visitor IN/OUT Time:</td><td>______ / ______</td></tr>
    <tr><td class='bold'>Visitor Pass No. & Date:</td><td>______ / ______</td></tr>
    <tr><td class='bold'>Visitor Pass (Deposited/Not Deposited):</td><td>______________________</td></tr>
</table>
";

// Generate PDF
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

// Download PDF
$dompdf->stream("Visitor_Form_{$visitor_id}.pdf", ["Attachment" => true]);
exit;
?>
