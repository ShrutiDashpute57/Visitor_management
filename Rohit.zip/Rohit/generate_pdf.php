<?php
require 'vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $visitor_name = htmlspecialchars($_POST['visitor_name']);
    $department = htmlspecialchars($_POST['department']);
    $contact_person = htmlspecialchars($_POST['contact_person']);
    $firm_name = htmlspecialchars($_POST['firm_name']);
    $purpose = htmlspecialchars($_POST['purpose']);
    $date_time = htmlspecialchars($_POST['date_time']);

    // Initialize Dompdf with options
    $options = new Options();
    $options->set('defaultFont', 'Arial');
    $dompdf = new Dompdf($options);

    // HTML content for PDF
    $html = "
    <style>
        body { font-family: Arial, sans-serif; }
        h2 { text-align: center; }
        .container { padding: 20px; }
        p { margin: 5px 0; }
    </style>
    <div class='container'>
        <h2>REQUISITION FOR ENTRY OF VISITOR TO ACEM</h2>
        <p><strong>Name of Visitor:</strong> $visitor_name</p>
        <p><strong>Department:</strong> $department</p>
        <p><strong>Contact Person:</strong> $contact_person</p>
        <p><strong>Firm Name & Address:</strong> $firm_name</p>
        <p><strong>Purpose of Visit:</strong> $purpose</p>
        <p><strong>Date & Time of Arrival:</strong> $date_time</p>
        <br>
        <p>________________________</p>
        <p>Signature</p>
    </div>";

    // Load HTML into Dompdf
    $dompdf->loadHtml($html);

    // (Optional) Set paper size
    $dompdf->setPaper('A4', 'portrait');

    // Render PDF
    $dompdf->render();

    // Download PDF
    $dompdf->stream("Visitor_Form.pdf", array("Attachment" => true));
}
?>
