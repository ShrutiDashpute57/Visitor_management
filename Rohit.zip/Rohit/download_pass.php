<?php
session_start();
require 'vendor/autoload.php'; // Include Dompdf library
include 'include/connection.php';

use Dompdf\Dompdf;
use Dompdf\Options;

if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

// Get pass_no from URL
$pass_no = isset($_GET['id']) ? trim($_GET['id']) : '';

if (empty($pass_no)) {
    echo "<script>alert('Invalid Pass Number.'); window.location='manage_pass.php';</script>";
    exit();
}

// Fetch pass details
$query = "SELECT * FROM tbl_pass WHERE pass_no = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $pass_no); // "s" for string
$stmt->execute();
$result = $stmt->get_result();
$pass = $result->fetch_assoc();
$stmt->close();

if (!$pass) {
    echo "<script>alert('Pass not found.'); window.location='manage_pass.php';</script>";
    exit();
}

// Initialize Dompdf
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('defaultFont', 'Arial');
$dompdf = new Dompdf($options);

// Create HTML content for PDF
$html = "
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <title>Out Pass - {$pass['name']}</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; }
        .pass-container { width: 95%; margin: auto; border: 2px solid black; padding: 20px; }
        .pass-title { font-size: 24px; font-weight: bold; text-decoration: underline; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid black; padding: 10px; text-align: left; font-size: 16px; }
        th { background:rgb(252, 247, 247); text-align: left; }
        .signature { margin-top: 30px; }
    </style>
</head>
<body>
    <div class='pass-container'>
        <p class='pass-title'>OUT PASS</p>
        <table>
            <tr>
                <th>Name & Designation</th>
                <td>{$pass['name']} - {$pass['designation']}</td>
            </tr>
            <tr>
                <th>Date</th>
                <td>" . date('d-m-Y', strtotime($pass['date'])) . "</td>
            </tr>
            <tr>
                <th>Purpose</th>
                <td>{$pass['purpose']}</td>
            </tr>
            
            <tr>
                <th>Section</th>
                <td>{$pass['department']}</td>
            </tr>
             <tr>
                <th>Sign Of Individual: </th>
                <td>____________________</td>
            </tr>
             <tr>
                <th>Name of Initiating Officer: </th>
                <td>{$pass['initiating_officer']}</td>
            </tr>

             <tr>
                <th>Officer Designation: </th>
                <td>{$pass['officer_designation']}</td>
            </tr>
            <tr>
                <th>Sign Of Initiating Officer: </th>
                <td>____________________</td>
            </tr>
            <tr>
                <th>Out Time</th>
                <td>{$pass['out_time']}</td>
            </tr>
              <tr>
                <th>Sign of Security Person: </th>
                <td>____________________</td>
            </tr>
            
           
        </table>
    </div>
</body>
</html>";

// Load HTML into Dompdf
$dompdf->loadHtml($html);

// Set paper size and orientation
$dompdf->setPaper('A4', 'portrait');

// Render PDF
$dompdf->render();

// Output PDF for download
$dompdf->stream("OutPass_{$pass_no}.pdf", ["Attachment" => true]);
exit();
?>
