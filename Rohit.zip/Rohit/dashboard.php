<?php
session_start();
include 'include/connection.php';

// Check if session variables exist
if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

$id = $_SESSION['id'];
$name = $_SESSION['name'] ?? 'User';

// Function to run queries and check for errors
function fetch_count($conn, $query) {
    $result = mysqli_query($conn, $query);
    if (!$result) {
        die("Database Query Failed: " . mysqli_error($conn));
    }
    return mysqli_fetch_row($result)[0] ?? 0; // Return 0 if no result
}

// Ensure the table exists before querying
$total_visitors = fetch_count($conn, "SELECT COUNT(*) FROM tbl_visitors");
$today_visitors = fetch_count($conn, "SELECT COUNT(*) FROM tbl_visitors WHERE DATE(in_time) = CURDATE()");
$yesterday_visitors = fetch_count($conn, "SELECT COUNT(*) FROM tbl_visitors WHERE DATE(in_time) = CURDATE() - INTERVAL 1 DAY");
$week_visitors = fetch_count($conn, "SELECT COUNT(*) FROM tbl_visitors WHERE DATE(in_time) >= CURDATE() - INTERVAL 7 DAY");

?>

<?php include('include/header.php'); ?>

<div id="wrapper">
    <?php include('include/side-bar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">

            <!-- Breadcrumbs -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            </ol>
            <h3>Welcome, <?= htmlspecialchars($name); ?></h3>

            <div class="row">
                <div class="col-sm-3">
                    <section class="panel panel-featured-left panel-featured-primary">
                        <div class="panel-body">
                            <div class="widget-summary">
                                <div class="widget-summary-col widget-summary-col-icon">
                                    <div class="summary-icon bg-secondary">
                                        <i class="fa fa-user"></i>
                                    </div>
                                </div>
                                <div class="widget-summary-col">
                                    <div class="summary">
                                        <h4 class="title">Total Visitors</h4>
                                        <div class="info">
                                            <strong class="amount"><?= $total_visitors; ?></strong>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>

                <div class="col-sm-3">
                    <section class="panel panel-featured-left panel-featured-primary">
                        <div class="panel-body">
                            <div class="widget-summary">
                                <div class="widget-summary-col widget-summary-col-icon">
                                    <div class="summary-icon bg-secondary">
                                        <i class="fa fa-user"></i>
                                    </div>
                                </div>
                                <div class="widget-summary-col">
                                    <div class="summary">
                                        <h4 class="title">Today Visitors</h4>
                                        <div class="info">
                                            <strong class="amount"><?= $today_visitors; ?></strong>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>

                <div class="col-sm-3">
                    <section class="panel panel-featured-left panel-featured-primary">
                        <div class="panel-body">
                            <div class="widget-summary">
                                <div class="widget-summary-col widget-summary-col-icon">
                                    <div class="summary-icon bg-secondary">
                                        <i class="fa fa-user"></i>
                                    </div>
                                </div>
                                <div class="widget-summary-col">
                                    <div class="summary">
                                        <h4 class="title">Yesterday Visitors</h4>
                                        <div class="info">
                                            <strong class="amount"><?= $yesterday_visitors; ?></strong>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>

                <div class="col-sm-3">
                    <section class="panel panel-featured-left panel-featured-primary">
                        <div class="panel-body">
                            <div class="widget-summary">
                                <div class="widget-summary-col widget-summary-col-icon">
                                    <div class="summary-icon bg-secondary">
                                        <i class="fa fa-user"></i>
                                    </div>
                                </div>
                                <div class="widget-summary-col">
                                    <div class="summary">
                                        <h4 class="title">Last 7 Days Visitors</h4>
                                        <div class="info">
                                            <strong class="amount"><?= $week_visitors; ?></strong>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top"><i class="fas fa-angle-up"></i></a>

<?php include('include/footer.php'); ?>
