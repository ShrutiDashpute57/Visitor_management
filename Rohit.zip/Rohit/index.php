<?php
session_start();
include 'include/connection.php';

if (isset($_POST['login_btn'])) {
    $email = trim($_POST['email']);
    $pwd = $_POST['pwd'];
    $role = $_POST['role'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format');</script>";
    } else {
        $stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE emailid = ? AND role = ?");
        $stmt->bind_param("ss", $email, $role);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if ($pwd === $user['password']) {
                $_SESSION['id'] = $user['id'];
                $_SESSION['name'] = $user['username'];
                $_SESSION['email'] = $email;
                $_SESSION['role'] = $user['role'];

                switch ($user['role']) {
                    case 'Admin': header("Location: dashboard.php"); break;
                    case 'Initiator': header("Location: initiator/initiator_dashboard.php"); break;
                    case 'Security': header("Location: security_dashboard.php"); break;
                    default: header("Location: dashboard.php");
                }
                exit();
            } else {
                echo "<script>alert('Incorrect email or password.');</script>";
            }
        } else {
            echo "<script>alert('Invalid credentials or role selection.');</script>";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Visitor Management</title>
    <link rel="stylesheet" href="css/xyz.css">
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <h2>Login</h2>
            <form method="post">
                <div class="input-group">
                    <label>Email</label>
                    <input type="email" name="email" required>
                </div>
                <div class="input-group">
                    <label>Password</label>
                    <input type="password" name="pwd" required>
                </div>
                <div class="input-group">
                    <label>Role</label>
                    <select name="role" required>
                        <option value="" disabled selected>Select Role</option>
                        <option value="Admin">Admin</option>
                        <option value="Initiator">Initiator</option>
                        <option value="Security">Security</option>
                    </select>
                </div>
                <button type="submit" name="login_btn">Login</button>
            </form>
        </div>
    </div>
</body>
</html>
