<?php
session_start();
include 'include/connection.php';

if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

// Accept or Reject Out Pass Request
if (isset($_GET['action']) && isset($_GET['id'])) {
    $pass_id = mysqli_real_escape_string($conn, $_GET['id']);
    $status = ($_GET['action'] == "accept") ? 1 : 2; // 1 = Accepted, 2 = Rejected

    $updateQuery = "UPDATE tbl_pass SET status='$status' WHERE pass_no='$pass_id'";
    mysqli_query($conn, $updateQuery);
    header("Location: manage_pass.php");
    exit();
}

// Delete Out Pass Request
if (isset($_GET['delete_id'])) {
    $pass_id = mysqli_real_escape_string($conn, $_GET['delete_id']);
    mysqli_query($conn, "DELETE FROM tbl_pass WHERE pass_no='$pass_id'");
    header("Location: manage_pass.php");
    exit();
}

?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Manage Out Passes</a>
                </li>
            </ol>

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-id-card"></i> Out Pass Requests
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Pass No</th>
                                    <th>Name</th>
                                    <th>Designation</th>
                                    <th>Date</th>
                                    <th>Department</th>
                                    <th>Purpose</th>
                                    <th>Initiating Officer</th>
                                    <th>Officer's Designation</th>
                                    <th>Out Time</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT * FROM tbl_pass ORDER BY created_at DESC";
                                $result = mysqli_query($conn, $query);
                                $sn = 1;

                                while ($row = mysqli_fetch_assoc($result)) {
                                    // Ensure status exists before using it
                                    $statusText = "<span class='badge badge-warning'>Pending</span>";
                                    if (isset($row['status'])) {
                                        if ($row['status'] == 1) {
                                            $statusText = "<span class='badge badge-success'>Accepted</span>";
                                        } elseif ($row['status'] == 2) {
                                            $statusText = "<span class='badge badge-danger'>Rejected</span>";
                                        }
                                    }

                                    echo "<tr>
                                        <td>{$sn}</td>
                                        <td>{$row['pass_no']}</td>
                                        <td>" . htmlspecialchars($row['name']) . "</td>
                                        <td>" . htmlspecialchars($row['designation']) . "</td>
                                        <td>{$row['date']}</td>
                                        <td>" . htmlspecialchars($row['department']) . "</td>
                                        <td>" . htmlspecialchars($row['purpose']) . "</td>
                                        <td>" . htmlspecialchars($row['initiating_officer']) . "</td>
                                        <td>" . htmlspecialchars($row['officer_designation']) . "</td>
                                        <td>{$row['out_time']}</td>
                                        <td>$statusText</td>
                                        <td>
                                            <a href='edit_pass.php?id={$row['pass_no']}' class='btn btn-info btn-sm'><i class='fa fa-edit'></i> Edit</a>
                                            <a href='manage_pass.php?delete_id={$row['pass_no']}' class='btn btn-danger btn-sm' onclick='return confirmDelete()'><i class='fa fa-trash'></i> Delete</a>";
                                    
                                    if (!isset($row['status']) || $row['status'] == 0) { // Pending Status
                                        echo "
                                            <a href='manage_pass.php?action=accept&id={$row['pass_no']}' class='btn btn-success btn-sm'><i class='fa fa-check'></i> Accept</a>
                                            <a href='manage_pass.php?action=reject&id={$row['pass_no']}' class='btn btn-danger btn-sm'><i class='fa fa-times'></i> Reject</a>";
                                    } elseif ($row['status'] == 1) { // Accepted Status
                                        echo "
                                            <a href='download_pass.php?id={$row['pass_no']}' class='btn btn-primary btn-sm'><i class='fa fa-download'></i> Download Pass</a>";
                                    }

                                    echo "</td></tr>";
                                    $sn++;
                                }

                                if (mysqli_num_rows($result) == 0) {
                                    echo "<tr><td colspan='12' class='text-center'>No Out Pass Requests Found</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>

<script>
function confirmDelete() {
    return confirm('Are you sure you want to delete this Out Pass request?');
}
</script>
