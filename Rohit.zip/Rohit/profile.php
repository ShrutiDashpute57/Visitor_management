<?php 
session_start();
include 'include/connection.php';

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    echo "<script>alert('You must be logged in to access this page.'); window.location='dashboard.php';</script>";
    exit();
}

// Fetch user details from the database securely
$id = $_SESSION['id'];
$query = "SELECT * FROM users WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

// Handle form submission
if (isset($_POST['update'])) {
    $name = trim($_POST['name']);
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $status = trim($_POST['status']);

    // Validate input fields
    if (empty($name) || empty($username) || empty($email)) {
        echo "<script>alert('All fields are required.');</script>";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format.');</script>";
    } else {
        // Use prepared statement to update user details
        $update_query = "UPDATE users SET name=?, username=?, emailid=?, status=? WHERE id=?";
        $stmt = mysqli_prepare($conn, $update_query);
        mysqli_stmt_bind_param($stmt, "ssssi", $name, $username, $email, $status, $id);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>alert('Profile updated successfully'); window.location='profile.php';</script>";
        } else {
            echo "<script>alert('Error updating profile');</script>";
        }
    }
}

include('include/header.php'); 
?>

<div id="wrapper">
    <?php include('include/side-bar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
            <h2 class="mt-3">User Profile</h2>
            <form method="POST" action="">
                <div class="form-group">
                    <label>Name:</label>
                    <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Username:</label>
                    <input type="text" name="username" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Email:</label>
                    <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['emailid']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Status:</label>
                    <select name="status" class="form-control">
                        <option value="Active" <?php if ($user['status'] == 'Active') echo 'selected'; ?>>Active</option>
                        <option value="Inactive" <?php if ($user['status'] == 'Inactive') echo 'selected'; ?>>Inactive</option>
                    </select>
                </div>
                <button type="submit" name="update" class="btn btn-primary">Update Profile</button>
            </form>
        </div>
    </div>
</div>

<?php include('include/footer.php'); ?>
