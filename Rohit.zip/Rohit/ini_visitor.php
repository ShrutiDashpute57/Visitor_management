<?php
session_start();
include 'include/connection.php';

$name = $_SESSION['name'];
$id = $_SESSION['id'];

if (empty($id)) {
    header("Location: index.php"); 
    exit();
}

if (isset($_POST['sbt-vstr'])) {
    $department = $_POST['department'];
    $escort_person = $_POST['fullname'];
    $contact_person_name = $_POST['contact_person'];
    $contact_person_tel = $_POST['contact_tel'];
    $visitor_name = $_POST['visitor_name'];
    $visitor_mobile = $_POST['visitor_mobile']; 
    $visitor_aadhar = $_POST['aadhar'];
    $visitor_vehicle = $_POST['vehicle'];
    $firm_name_address = $_POST['firm_address'];
    $arrival_datetime = $_POST['arrival_datetime']; 
    $area_facility = $_POST['facility_type'];
    $purpose_visit = $_POST['purpose_visit'];
    $remark = isset($_POST['remark']) ? $_POST['remark'] : ''; // Handle optional remark

    // ✅ Validate Mobile Number (10 digits)
    if (!preg_match('/^[0-9]{10}$/', $visitor_mobile)) {
        echo "<script>alert('❌ Invalid Mobile Number! It must be exactly 10 digits.'); window.history.back();</script>";
        exit();
    }

    // ✅ Validate Aadhar Number (12 digits)
    if (!preg_match('/^[0-9]{12}$/', $visitor_aadhar)) {
        echo "<script>alert('❌ Invalid Aadhar Number! It must be exactly 12 digits.'); window.history.back();</script>";
        exit();
    }

    // ✅ Prepared statement to prevent SQL Injection
    $stmt = $conn->prepare("INSERT INTO tbl_visitors 
        (department, escort_person, contact_person_name, contact_person_tel, visitor_name, visitor_mobile, purpose_visit, visitor_aadhar, visitor_vehicle, firm_name_address, arrival_datetime, area_facility, remark) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->bind_param("sssssssssssss", $department, $escort_person, $contact_person_name, $contact_person_tel, $visitor_name, $visitor_mobile, $purpose_visit, $visitor_aadhar, $visitor_vehicle, $firm_name_address, $arrival_datetime, $area_facility, $remark);

    if ($stmt->execute()) {
        echo "<script>alert('✅ Visitor added successfully.'); window.location.href='manage-visitors.php';</script>";
    } else {
        echo "<script>alert('❌ Error: " . $stmt->error . "'); window.history.back();</script>";
    }
    $stmt->close();
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/ini_side.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Add Visitors</a>
                </li>
            </ol>
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-info-circle"></i> Submit Details
                </div>
                <form method="post" class="form-valide">
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Department <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <select name="department" class="form-control" required>
                                    <option value="">Select Department</option>
                                    <?php
                                    $select_department = mysqli_query($conn, "SELECT * FROM tbl_department WHERE status=1");
                                    while ($dept = mysqli_fetch_array($select_department)) {
                                    ?>
                                        <option><?php echo $dept['department']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Escort Person <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="fullname" class="form-control" placeholder="Enter Name" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Name of the Contact Person <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="contact_person" class="form-control" placeholder="Enter Name" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Contact Person Tel. No. <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="contact_tel" class="form-control" placeholder="Enter Mobile No." required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Visitor Name <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="visitor_name" class="form-control" placeholder="Enter Visitor Name" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Purpose of Visit <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="purpose_visit" class="form-control" placeholder="Enter Purpose of Visit" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Visitor Mobile No. <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="visitor_mobile" class="form-control" placeholder="Enter Mobile No." required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Visitor Aadhar No. <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="aadhar" class="form-control" placeholder="Enter Aadhar No." required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Visitor Vehicle No. <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="vehicle" class="form-control" placeholder="Enter Vehicle No." required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Firm Name & Address <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="firm_address" class="form-control" placeholder="Enter Firm Name & Address" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Arrival Date & Time <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="datetime-local" name="arrival_datetime" class="form-control" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Area Facility <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <select name="facility_type" class="form-control" required>
                                    <option value="">Select Facility Type</option>
                                    <option value="Technical">Technical</option>
                                    <option value="Non-Technical">Non-Technical</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-lg-8 ml-auto">
                                <button type="submit" name="sbt-vstr" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include('include/footer.php'); ?>
