<?php
session_start();
include 'include/connection.php';

if (!isset($_SESSION['id'])) {
    header("Location: index.php"); 
    exit();
}

if (isset($_GET['id'])) {
    $visitor_id = $_GET['id'];
    $query = "SELECT * FROM tbl_visitors WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $visitor_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $visitor = $result->fetch_assoc();
    $stmt->close();
} else {
    echo "<script>alert('No visitor selected.'); window.location='index.php';</script>";
    exit();
}

if (isset($_POST['update-visitor'])) {
    $department = $_POST['department'];
    $escort_person = $_POST['fullname'];
    $contact_person_name = $_POST['contact_person'];
    $contact_person_tel = $_POST['contact_tel'];
    $visitor_name = $_POST['visitor_name'];
    $visitor_mobile = $_POST['contact_tel'];
    $visitor_aadhar = $_POST['aadhar'];
    $visitor_vehicle = $_POST['vehicle'];
    $firm_name_address = $_POST['firm_address'];
    $arrival_datetime = $_POST['arrival_datetime'];
    $area_facility = $_POST['facility_type'];
    $purpose_visit = $_POST['purpose_visit'];

    // Validation
    if (!preg_match('/^[0-9]{10}$/', $visitor_mobile)) {
        echo "<script>alert('❌ Invalid Mobile Number! It must be exactly 10 digits.'); window.history.back();</script>";
        exit();
    }
    if (!preg_match('/^[0-9]{12}$/', $visitor_aadhar)) {
        echo "<script>alert('❌ Invalid Aadhar Number! It must be exactly 12 digits.'); window.history.back();</script>";
        exit();
    }

    // Update query
    // Update query
    $query = "UPDATE tbl_visitors SET department=?, escort_person=?, contact_person_name=?, contact_person_tel=?, visitor_name=?, visitor_mobile=?, purpose_visit=?, visitor_aadhar=?, visitor_vehicle=?, firm_name_address=?, arrival_datetime=?, area_facility=? WHERE id=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssssssssssssi", $department, $escort_person, $contact_person_name, $contact_person_tel, $visitor_name, $visitor_mobile, $purpose_visit, $visitor_aadhar, $visitor_vehicle, $firm_name_address, $arrival_datetime, $area_facility, $visitor_id);


    if ($stmt->execute()) {
        echo "<script>alert('Visitor details updated successfully.'); window.location='manage-visitors.php';</script>";
    } else {
        echo "<script>alert('Error updating record: " . $stmt->error . "');</script>";
    }
    $stmt->close();
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Edit Visitor</a></li>
            </ol>
            <div class="card mb-3">
                <div class="card-header"><i class="fa fa-edit"></i> Update Visitor Details</div>
                <form method="post" class="form-valide">
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label" for="department">Department</label>
                            <div class="col-lg-6">
                                <select name="department" class="form-control" required>
                                    <option value="<?php echo $visitor['department']; ?>" selected><?php echo $visitor['department']; ?></option>
                                    <?php
                                    $select_department = mysqli_query($conn, "SELECT * FROM tbl_department WHERE status=1");
                                    while ($dept = mysqli_fetch_array($select_department)) {
                                    ?>
                                        <option><?php echo $dept['department']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>


                      


                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Escort Person:</label>
                            <div class="col-lg-6">
                                <input type="text" name="fullname" class="form-control" value="<?php echo $visitor['escort_person']; ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Contact Person:</label>
                            <div class="col-lg-6">
                                <input type="text" name="contact_person" class="form-control" value="<?php echo $visitor['contact_person_name']; ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Contact Tel:</label>
                            <div class="col-lg-6">
                                <input type="text" name="contact_tel" class="form-control" value="<?php echo $visitor['contact_person_tel']; ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Visitor Name:</label>
                            <div class="col-lg-6">
                                <input type="text" name="visitor_name" class="form-control" value="<?php echo $visitor['visitor_name']; ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Visitor Mobile:</label>
                            <div class="col-lg-6">
                                <input type="text" name="contact_tel" class="form-control" value="<?php echo $visitor['visitor_mobile']; ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Purpose of Visit: <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="purpose_visit" class="form-control" value="<?php echo $visitor['purpose_visit']; ?>" required>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Aadhar Number:</label>
                            <div class="col-lg-6">
                                <input type="text" name="aadhar" class="form-control" value="<?php echo $visitor['visitor_aadhar']; ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Vehicle No:</label>
                            <div class="col-lg-6">
                                <input type="text" name="vehicle" class="form-control" value="<?php echo $visitor['visitor_vehicle']; ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Firm Address:</label>
                            <div class="col-lg-6">
                                <input type="text" name="firm_address" class="form-control" value="<?php echo $visitor['firm_name_address']; ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Arrival Date & Time:</label>
                            <div class="col-lg-6">
                                <input type="datetime-local" name="arrival_datetime" class="form-control" value="<?php echo $visitor['arrival_datetime']; ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                        <label class="col-lg-4 col-form-label">Area Facility to be Visited:</label>
                            <div class="col-lg-6">
                            <select name="facility_type" class="form-control" required>
                                    <option value="">Select Facility Type</option>
                                    <option value="Technical">Technical</option>
                                    <option value="Non-Technical">Non-Technical</option>
                                </select>
                            </div>
                        </div>
                        <button type="submit" name="update-visitor" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include('include/footer.php'); ?>
