-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2025 at 03:29 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_department`
--

CREATE TABLE `tbl_department` (
  `id` int(11) NOT NULL,
  `department` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `hod` varchar(50) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1=Active, 0=Inactive',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_department`
--

INSERT INTO `tbl_department` (`id`, `department`, `description`, `hod`, `status`, `created_at`) VALUES
(3, 'Subscale', 'Subscale', 'EMP345', 1, '2025-02-26 09:09:26'),
(4, 'HR', 'Human Resource Department', 'EMP123', 1, '2025-02-26 09:04:49'),
(5, 'RAW', 'Raw Material', 'EMP678', 1, '2025-02-26 09:12:57'),
(6, 'RAW', 'Raw Material', 'EMP679', 1, '2025-02-26 09:13:49');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_visitors`
--

CREATE TABLE `tbl_visitors` (
  `id` int(11) NOT NULL,
  `department` varchar(100) NOT NULL,
  `escort_person` varchar(100) NOT NULL,
  `contact_person_name` varchar(100) NOT NULL,
  `contact_person_tel` varchar(20) NOT NULL,
  `visitor_name` varchar(100) NOT NULL,
  `visitor_mobile` varchar(20) NOT NULL,
  `visitor_aadhar` varchar(20) NOT NULL,
  `visitor_vehicle` varchar(50) NOT NULL,
  `firm_name_address` text NOT NULL,
  `arrival_datetime` datetime NOT NULL,
  `area_facility` enum('Technical','Non-Technical') NOT NULL,
  `remark` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) DEFAULT 0,
  `in_time` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_visitors`
--

INSERT INTO `tbl_visitors` (`id`, `department`, `escort_person`, `contact_person_name`, `contact_person_tel`, `visitor_name`, `visitor_mobile`, `visitor_aadhar`, `visitor_vehicle`, `firm_name_address`, `arrival_datetime`, `area_facility`, `remark`, `created_at`, `status`, `in_time`) VALUES
(3, 'HRD', 'Shubhaman Gill', 'Shreyas Iyer', '9875848595', 'Ishan Kisan', '9875848595', '336575847192', 'MH15JU4809', 'Infosys Pvt.Ltd', '2025-02-26 14:45:00', '', NULL, '2025-02-25 17:15:50', 2, '2025-02-26 14:58:01'),
(5, 'HRD', 'Shruti', 'Shruti ', '8668576498', 'Virat Kohli', '8668576498', '336575847192', 'MH15JU4809', 'Flat No 19, ALfa Crecent Society College Road Nashik', '2025-02-27 14:19:00', 'Non-Technical', NULL, '2025-02-26 08:50:15', 1, '2025-02-26 14:58:01'),
(6, 'Subscale', 'Pawan Kumar Soni', 'Nisha Nandan', '6857485974', 'Shreyas Iyer', '6857485974', '125874589575', 'MH15JU4585', 'Minitek Pvt.LTD', '2025-02-27 18:28:00', 'Technical', NULL, '2025-02-26 08:58:20', 0, '2025-02-26 14:58:01');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `emailid` varchar(100) NOT NULL,
  `role` enum('Admin','Initiator','Security') DEFAULT 'Initiator',
  `status` enum('active','inactive') DEFAULT 'active',
  `purpose_visit` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `emailid`, `role`, `status`, `purpose_visit`) VALUES
(1, 'John Doe', 'johndoe', 'pass123', 'jon@gmail.com', 'Admin', 'active', ''),
(2, 'Jane Smith', 'janesmith', 'mypassword', 'jane@example.com', 'Initiator', 'active', ''),
(3, 'Security Guy', 'security01', 'securepass', 'security@example.com', 'Security', 'active', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_department`
--
ALTER TABLE `tbl_department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_visitors`
--
ALTER TABLE `tbl_visitors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `emailid` (`emailid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_department`
--
ALTER TABLE `tbl_department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_visitors`
--
ALTER TABLE `tbl_visitors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
