-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2025 at 07:41 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `printer`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_add`
--

CREATE TABLE `tbl_add` (
  `id` int(11) NOT NULL,
  `cart_no` varchar(100) DEFAULT NULL,
  `supply_order` varchar(100) DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `officer_name` varchar(100) DEFAULT NULL,
  `officer_designation` varchar(100) DEFAULT NULL,
  `demand_quantity` int(11) DEFAULT NULL,
  `request_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_add`
--

INSERT INTO `tbl_add` (`id`, `cart_no`, `supply_order`, `department`, `officer_name`, `officer_designation`, `demand_quantity`, `request_date`) VALUES
(1, 'CR565N', '24656GSDFD', 5, 'Nisha Nandan', 'To B', 2, '2025-05-01 17:13:23');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cartridge`
--

CREATE TABLE `tbl_cartridge` (
  `id` int(50) NOT NULL,
  `printer_name` varchar(255) NOT NULL,
  `part_no` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `cart_no` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_cartridge`
--

INSERT INTO `tbl_cartridge` (`id`, `printer_name`, `part_no`, `color`, `cart_no`) VALUES
(21, 'DELL', '4576', 'black', 'CR987N'),
(22, 'HP', '4576', 'yellow', 'CR345N'),
(23, 'Canon', '873d', 'magenta', 'CR565N'),
(24, 'Toshiba', '873d', 'white', 'CR448N'),
(26, 'DELL', '457f', 'Yellow', 'CR9655N');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_department`
--

CREATE TABLE `tbl_department` (
  `id` int(11) NOT NULL,
  `department` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `hod` varchar(50) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1=Active, 0=Inactive',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_department`
--

INSERT INTO `tbl_department` (`id`, `department`, `description`, `hod`, `status`, `created_at`) VALUES
(4, 'HRD', 'Human Resource Department', 'EMP123', 1, '2025-02-28 14:47:32'),
(5, 'RAW', 'Raw Material', 'EMP678', 1, '2025-02-26 09:12:57'),
(7, 'NDT', 'NDT', 'EMP945', 1, '2025-02-27 17:00:42'),
(8, 'QC', 'Quality Control', 'EMP345', 1, '2025-02-27 18:04:03'),
(9, 'CSG', 'Computer Section Group', 'EMP892', 1, '2025-02-28 08:54:21'),
(10, 'QA', 'Quality Assurance', 'EMP545', 1, '2025-02-28 14:13:31'),
(11, 'MMD', 'Material Management Division', 'EMP934', 1, '2025-02-28 14:48:17'),
(12, 'Trimming', 'Trimming', 'EMP946', 1, '2025-02-28 16:52:21'),
(13, 'Inhibition', 'Inhibition', 'EMP698', 1, '2025-03-02 09:42:34'),
(15, 'Account', 'Account', 'EMP057', 1, '2025-04-28 09:38:53');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE `tbl_employee` (
  `emp_id` int(11) NOT NULL,
  `emp_code` varchar(50) NOT NULL,
  `emp_name` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `department` int(11) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`emp_id`, `emp_code`, `emp_name`, `designation`, `department`, `contact_no`, `email`, `created_at`) VALUES
(1, '8219', 'Nisha Nandan', 'TO \'B\'', 9, '9685748596', 'nisha@gmail.com', '2025-03-08 13:35:19'),
(2, '8217', 'Saneep Gupta', 'STA \'B\'', 4, '9685748596', 'sandeepgupta@gmail.com', '2025-03-08 13:36:01'),
(3, '8215', 'Vishal Sejwal', 'TO \'A\'', 9, '9687485987', 'vishal@gmail.com', '2025-03-08 13:57:16'),
(6, '8220', 'Nisha Nandan', 'TO \'B\'', 9, '9685748596', 'abc@gmail.com', '2025-03-16 15:32:33'),
(7, '9832', 'Monali Shirsath', 'Technical Documentation Writer', 4, '9876543218', 'monali@gmail.com', '2025-04-28 10:09:07');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_printer`
--

CREATE TABLE `tbl_printer` (
  `id` int(11) NOT NULL,
  `printer_name` varchar(255) NOT NULL,
  `part_no` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_printer`
--

INSERT INTO `tbl_printer` (`id`, `printer_name`, `part_no`) VALUES
(14, 'HP', '457f'),
(15, 'HP', '234'),
(16, 'HP', '4576'),
(18, 'HP', '1606'),
(19, 'DELL', '678f'),
(20, 'Canon', '678d'),
(21, 'Toshiba', '873d'),
(22, 'HP', '546h');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_request`
--

CREATE TABLE `tbl_request` (
  `id` int(11) NOT NULL,
  `demand_no` varchar(50) NOT NULL,
  `printer_id` int(11) NOT NULL,
  `part_no` varchar(100) NOT NULL,
  `department_id` int(11) NOT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_request`
--

INSERT INTO `tbl_request` (`id`, `demand_no`, `printer_id`, `part_no`, `department_id`, `status`, `created_at`, `updated_at`) VALUES
(1, '2025/Demand/01', 8, '123d', 11, 'Approved', '2025-04-26 10:14:31', '2025-04-26 10:16:29'),
(2, '2025/Demand/02', 11, '123d', 9, 'Rejected', '2025-04-27 17:43:08', '2025-04-27 17:43:25'),
(3, '2025/Demand/03', 546, '', 8, 'Pending', '2025-04-28 10:07:04', '2025-04-28 10:07:04');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stock`
--

CREATE TABLE `tbl_stock` (
  `id` int(50) NOT NULL,
  `printer_name` varchar(255) NOT NULL,
  `part_no` varchar(100) NOT NULL,
  `cart_no` varchar(100) NOT NULL,
  `supply_order` varchar(255) NOT NULL,
  `order_date` date NOT NULL,
  `quantity` int(50) NOT NULL,
  `received_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_stock`
--

INSERT INTO `tbl_stock` (`id`, `printer_name`, `part_no`, `cart_no`, `supply_order`, `order_date`, `quantity`, `received_date`) VALUES
(1, 'Canon', '873d', 'CR565N', '24656', '2025-04-28', 6, '2025-04-14'),
(2, 'DELL', '457f', 'CR565N', '24656GSDFD', '2025-04-27', 10, '2025-04-15'),
(3, 'DELL', '457f', 'CR565N', '24656GSDFD', '2025-04-28', 3, '2025-04-10'),
(4, 'DELL', '457f', 'CR987N', '13456767ACEM', '2025-04-25', 7, '2025-04-03'),
(5, 'Canon', '234', 'CR448N', '24656', '2025-04-22', 6, '2025-04-16'),
(6, 'DELL', '457f', 'CR565N', '3456dfg', '2025-04-16', 9, '2025-03-21'),
(7, 'Canon', '456t', 'CR448N', '24656', '2025-04-28', 6, '2025-05-15');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `emailid` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `user_name`, `emailid`, `password`, `created_at`) VALUES
(1, 'admin', 'admin@gmail.com', '6b8d5de3b53751bac499eb1bef762a2a', '2023-08-26 13:15:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_add`
--
ALTER TABLE `tbl_add`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cartridge`
--
ALTER TABLE `tbl_cartridge`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cart_no` (`cart_no`);

--
-- Indexes for table `tbl_department`
--
ALTER TABLE `tbl_department`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `hod` (`hod`);

--
-- Indexes for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  ADD PRIMARY KEY (`emp_id`),
  ADD UNIQUE KEY `emp_code` (`emp_code`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `department_id` (`department`);

--
-- Indexes for table `tbl_printer`
--
ALTER TABLE `tbl_printer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `part_no` (`part_no`);

--
-- Indexes for table `tbl_request`
--
ALTER TABLE `tbl_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_stock`
--
ALTER TABLE `tbl_stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_add`
--
ALTER TABLE `tbl_add`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_cartridge`
--
ALTER TABLE `tbl_cartridge`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tbl_department`
--
ALTER TABLE `tbl_department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_printer`
--
ALTER TABLE `tbl_printer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_request`
--
ALTER TABLE `tbl_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_stock`
--
ALTER TABLE `tbl_stock`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  ADD CONSTRAINT `tbl_employee_ibfk_1` FOREIGN KEY (`department`) REFERENCES `tbl_department` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
