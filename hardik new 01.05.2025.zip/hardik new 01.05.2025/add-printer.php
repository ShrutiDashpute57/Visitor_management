<?php
session_start();
include 'include/connection.php';  // Database connection

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Handle Form Submission
if (isset($_POST['submit_printer'])) {
    $brand_name = trim($_POST['brand_name']);
    $model_no = trim($_POST['model_no']);

    // Check if Brand already exists
    $check_query = "SELECT * FROM tbl_printer WHERE printer_name = '$brand_name'";
    $check_result = mysqli_query($conn, $check_query);

    // if (mysqli_num_rows($check_result) > 0) {
    //     echo "<script>alert('Brand already exists!'); window.location.href='add-printer.php';</script>";
    // } else {
        // Insert new brand
        $insert_query = "INSERT INTO tbl_printer (printer_name, part_no) 
                         VALUES ('$brand_name', '$model_no')";

        if (mysqli_query($conn, $insert_query)) {
            echo "<script>alert('Printer added successfully!'); window.location.href='view-printer.php';</script>";
        } else {
            echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
        }
    }
    

?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">

            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Add Printer</a>
                </li>
            </ol>

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fas fa-plus"></i> Submit Printer Details
                </div>

                <form method="post">
                    <div class="card-body">
                        
                        <!-- Brand Name -->
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Brand Name <span style="color:red;">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="brand_name" class="form-control" placeholder="Enter Brand Name (e.g., HP, Dell, Canon)" required>
                            </div>
                        </div>

                        <!-- Model No -->
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Model No <span style="color:red;">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="model_no" class="form-control" placeholder="Enter Model Number" required>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="form-group row">
                            <div class="col-lg-8 ml-auto">
                                <button type="submit" name="submit_printer" class="btn btn-primary">Submit</button>
                                <a href="view_printer.php" class="btn btn-secondary">Cancel</a>
                            </div>
                        </div>

                    </div>
                </form>

            </div>

        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>
