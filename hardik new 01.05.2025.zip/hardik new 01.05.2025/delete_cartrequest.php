<?php
session_start();
include 'include/connection.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Request ID is missing.");
}

$id = $_GET['id'];

// Delete the request from the database
$query = "DELETE FROM tbl_add WHERE id = '$id'";

if (mysqli_query($conn, $query)) {
    echo "<script>alert('Request deleted successfully!'); window.location.href = 'view_cartrequests.php';</script>";
} else {
    echo "Error deleting request: " . mysqli_error($conn);
}
?>
