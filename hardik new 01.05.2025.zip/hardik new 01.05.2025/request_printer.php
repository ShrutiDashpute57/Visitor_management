<?php
session_start();
include 'include/connection.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Fetch Brand List (Printers)
$query_printers = "SELECT DISTINCT(printer_name) FROM tbl_printer";
$result_printers = mysqli_query($conn, $query_printers);

// Fetch Department List
$query_departments = "SELECT * FROM tbl_department";
$result_departments = mysqli_query($conn, $query_departments);

// Fetch Model Number
$query_model = "SELECT DISTINCT (part_no) FROM tbl_printer";
$result_model = mysqli_query($conn, $query_model);


// Generate Demand Number
$year = date("Y");
$query_demand = "SELECT COUNT(*) AS total FROM tbl_request";
$result_demand = mysqli_query($conn, $query_demand);
$row_demand = mysqli_fetch_assoc($result_demand);
$demand_no = $year . "/Demand/" . str_pad($row_demand['total'] + 1, 2, '0', STR_PAD_LEFT);

// Handle Form Submission
if (isset($_POST['request_printer'])) {
    $demand_no = $_POST['demand_no'];
    $printer_id = $_POST['printer_id'];
    $model_no = $_POST['part_no'];
    $department_id = $_POST['department_id'];

    $insert_query = "INSERT INTO tbl_request (demand_no, printer_id, part_no, department_id, status) 
                     VALUES ('$demand_no', '$printer_id', '$model_no', '$department_id', 'Pending')";

    if (mysqli_query($conn, $insert_query)) {
        echo "<script>alert('Request submitted successfully.'); window.location.href='view_request.php';</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
    }
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Request Printer</a>
                </li>
            </ol>

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-edit"></i> Request Printer
                </div>

                <form method="post">
                    <div class="card-body">
                        <!-- Demand No -->
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Demand No</label>
                            <div class="col-lg-6">
                                <input type="text" name="demand_no" class="form-control" value="<?= $demand_no; ?>" readonly>
                            </div>
                        </div>

                        <!-- Select Brand Name -->
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Select Brand Name</label>
                            <div class="col-lg-6">
                                <select name="printer_id" class="form-control" required>
                                    <option value="">Select Brand Name</option>
                                    <?php while ($printer = mysqli_fetch_assoc($result_printers)) { ?>
                                        <option value="<?= $printer['printer_name']; ?>"><?= $printer['printer_name']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <!-- Model No -->
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Model No</label>
                            <div class="col-lg-6">
                                <!-- <input type="text" name="part_no" class="form-control" placeholder="Enter Model No" required> -->
                                <select name="printer_id" class="form-control" required>
                                    <option value="">Select Model No</option>
                                    <?php while ($model = mysqli_fetch_assoc($result_model)) { ?>
                                        <option value="<?= $model['part_no']; ?>"><?= $model['part_no']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <!-- Select Department -->
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Select Department</label>
                            <div class="col-lg-6">
                                <select name="department_id" class="form-control" required>
                                    <option value="">Select Department</option>
                                    <?php while ($department = mysqli_fetch_assoc($result_departments)) { ?>
                                        <option value="<?= $department['id']; ?>"><?= $department['department']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <!-- Submit Buttons -->
                        <div class="form-group row">
                            <div class="col-lg-8 ml-auto">
                                <button type="submit" name="request_printer" class="btn btn-primary">Request</button>
                                <a href="view_request.php" class="btn btn-secondary">Cancel</a>
                            </div>
                        </div>

                    </div>
                </form>
            </div>

        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>
