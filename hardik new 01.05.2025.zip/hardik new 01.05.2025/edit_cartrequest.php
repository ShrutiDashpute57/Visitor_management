<?php
session_start();
include 'include/connection.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Request ID is missing.");
}

$id = $_GET['id'];

// Fetch the request details
$query = "SELECT * FROM tbl_add WHERE id = '$id'";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    die("Request not found.");
}

$row = mysqli_fetch_assoc($result);

// Check for form submission to update data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cart_no = mysqli_real_escape_string($conn, $_POST['cart_no']);
    $supply_order = mysqli_real_escape_string($conn, $_POST['supply_order']);
    $officer_name = mysqli_real_escape_string($conn, $_POST['officer_name']);
    $officer_designation = mysqli_real_escape_string($conn, $_POST['officer_designation']);
    $demand_quantity = mysqli_real_escape_string($conn, $_POST['demand_quantity']);

    // Update query
    $update_query = "UPDATE tbl_add 
                     SET cart_no = '$cart_no', supply_order = '$supply_order', officer_name = '$officer_name',
                         officer_designation = '$officer_designation', demand_quantity = '$demand_quantity'
                     WHERE id = '$id'";

    if (mysqli_query($conn, $update_query)) {
        echo "<script>alert('Request updated successfully!'); window.location.href = 'view_cartrequest.php';</script>";
    } else {
        echo "Error updating request: " . mysqli_error($conn);
    }
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
<?php include('include/side-bar.php'); ?>

<div id="content-wrapper">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Edit Cartridge Request</a></li>
        </ol>

        <div class="card mb-3">
            <div class="card-header"><i class="fa fa-pencil"></i> Edit Cartridge Request</div>
            <div class="card-body">
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="cart_no">Cartridge No</label>
                        <input type="text" class="form-control" id="cart_no" name="cart_no" value="<?= htmlspecialchars($row['cart_no']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="supply_order">Supply Order</label>
                        <input type="text" class="form-control" id="supply_order" name="supply_order" value="<?= htmlspecialchars($row['supply_order']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="officer_name">Officer Name</label>
                        <input type="text" class="form-control" id="officer_name" name="officer_name" value="<?= htmlspecialchars($row['officer_name']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="officer_designation">Officer Designation</label>
                        <input type="text" class="form-control" id="officer_designation" name="officer_designation" value="<?= htmlspecialchars($row['officer_designation']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="demand_quantity">Demand Quantity</label>
                        <input type="number" class="form-control" id="demand_quantity" name="demand_quantity" value="<?= htmlspecialchars($row['demand_quantity']) ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Update Request</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include('include/footer.php'); ?>
