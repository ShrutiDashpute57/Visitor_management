<?php
include 'include/connection.php';

if (isset($_GET['cart_no'])) {
    $cart_no = $_GET['cart_no'];
    $query = "SELECT DISTINCT supply_order FROM tbl_stock WHERE cart_no = '$cart_no'";
    $result = mysqli_query($conn, $query);

    echo "<option value=''>--Select--</option>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<option value='{$row['supply_order']}'>{$row['supply_order']}</option>";
    }
}
?>
