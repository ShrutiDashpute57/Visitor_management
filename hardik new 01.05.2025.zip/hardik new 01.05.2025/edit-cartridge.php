<?php
session_start();
include 'include/connection.php';

$name = $_SESSION['name'];
$id = $_SESSION['id'];

if (empty($id)) {
    header("Location: index.php");
    exit();
}

$edit_id = $_GET['id'] ?? '';

if (empty($edit_id)) {
    echo "<script>alert('Invalid Request!'); window.location.href='view-cartridge.php';</script>";
    exit();
}

// Fetch cartridge details
$query = mysqli_query($conn, "SELECT * FROM tbl_cartridge WHERE id='$edit_id'");
$row = mysqli_fetch_assoc($query);

if (!$row) {
    echo "<script>alert('No cartridge found.'); window.location.href='view-cartridge.php';</script>";
    exit();
}

// Update cartridge details
if (isset($_POST['update'])) {
    $printer_name = $_POST['printer_name'];
    $part_no = $_POST['part_no'];
    $color = $_POST['color'];
    $cart_no = $_POST['cart_no'];

    $update = mysqli_query($conn, "UPDATE tbl_cartridge SET 
        printer_name='$printer_name', 
        part_no='$part_no', 
        color='$color', 
        cart_no='$cart_no'
        WHERE id='$edit_id'");

    if ($update) {
        echo "<script>alert('Cartridge updated successfully.'); window.location.href='view-cartridge.php';</script>";
    } else {
        echo "<script>alert('Error: Unable to update cartridge.'); window.location.href='edit-cartridge.php?id=$edit_id';</script>";
    }
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">

            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="view-cartridge.php">Manage Cartridge</a>
                </li>
                <li class="breadcrumb-item active">Edit Cartridge</li>
            </ol>

            <!-- Edit Cartridge Form -->
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-edit"></i> Edit Cartridge
                </div>
                <div class="card-body">
                    <form method="post">
                        <div class="form-group">
                            <label>Brand Name</label>
                            <input type="text" name="printer_name" class="form-control" required value="<?php echo htmlspecialchars($row['printer_name']); ?>">
                        </div>
                        <div class="form-group">
                            <label>Model Number</label>
                            <input type="text" name="part_no" class="form-control" required value="<?php echo htmlspecialchars($row['part_no']); ?>">
                        </div>
                        <div class="form-group">
                            <label>Color</label>
                            <input type="text" name="color" class="form-control" required value="<?php echo htmlspecialchars($row['color']); ?>">
                        </div>
                        <div class="form-group">
                            <label>Cartridge No</label>
                            <input type="text" name="cart_no" class="form-control" required value="<?php echo htmlspecialchars($row['cart_no']); ?>">
                        </div>
                        <button type="submit" name="update" class="btn btn-primary">Update</button>
                        <a href="view-cartridge.php" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>
