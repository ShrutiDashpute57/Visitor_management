<?php
session_start();
include 'include/connection.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Fetch cartridge requests (NO department involved)
$query = "SELECT id, cart_no, supply_order, officer_name, officer_designation, demand_quantity, request_date
          FROM tbl_add";
        //   ORDER BY id DESC";

$result = mysqli_query($conn, $query);

if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}


$result = mysqli_query($conn, $query);
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
<?php include('include/side-bar.php'); ?>

<div id="content-wrapper">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">View Cartridge Requests</a></li>
        </ol>

        <div class="card mb-3">
            <div class="card-header"><i class="fa fa-table"></i> Cartridge Request List</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Cartridge No</th>
                                <th>Supply Order</th>
                                <th>Officer Name</th>
                                <th>Designation</th>
                                <th>Demand Qty</th>
                                <th>Submitted On</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                                <tr>
                                    <td><?= $row['id'] ?></td>
                                    <td><?= htmlspecialchars($row['cart_no']) ?></td>
                                    <td><?= htmlspecialchars($row['supply_order']) ?></td>
                                    <td><?= htmlspecialchars($row['officer_name']) ?></td>
                                    <td><?= htmlspecialchars($row['officer_designation']) ?></td>
                                    <td><?= $row['demand_quantity'] ?></td>
                                    <td><?= $row['request_date'] ?? 'N/A' ?></td>
                                    <td>
                <a href="edit_cartrequest.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                <a href="delete_cartrequest.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this request?');">Delete</a>
            </td>
                                </tr>
                            <?php } ?>
                            <?php if (mysqli_num_rows($result) == 0): ?>
                                <tr><td colspan="7" class="text-center">No requests found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('include/footer.php'); ?>
