<?php
session_start();
include 'include/connection.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Fetch Brand List (Printers)
$query_printers = "SELECT DISTINCT(printer_name) FROM tbl_printer";
$result_printers = mysqli_query($conn, $query_printers);

// Fetch Department List
$query_departments = "SELECT * FROM tbl_department";
$result_departments = mysqli_query($conn, $query_departments);

// Fetch Model Number
$query_model = "SELECT DISTINCT (part_no) FROM tbl_printer";
$result_model = mysqli_query($conn, $query_model);

// Handle Form Submission
if (isset($_POST['submit_cart'])) {
    $color = trim($_POST['color']);
    $cart_no = trim($_POST['cart_no']);
    $part_no = trim($_POST['printer_id']);
    $printer= trim($_POST['printer_name']);

        // Insert 
        $insert_query = "INSERT INTO tbl_cartridge (color, cart_no, part_no, printer_name) 
                         VALUES ('$color', '$cart_no', '$part_no', '$printer')";

        if (mysqli_query($conn, $insert_query)) {
            echo "<script>alert('Cartridge added successfully!'); window.location.href='view-cartridge.php';</script>";
        } else {
            echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
        }
    }


?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Request Cartridge</a>
                </li>
            </ol>

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-edit"></i> Add Cartridge
                </div>

                <form method="post">
                    <div class="card-body">
                       

                        <!-- Select Brand Name -->
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Select Brand Name</label>
                            <div class="col-lg-6">
                                <select name="printer_name" class="form-control" required>
                                    <option value="">Select Brand Name</option>
                                    <?php while ($printer = mysqli_fetch_assoc($result_printers)) { ?>
                                        <option value="<?= $printer['printer_name']; ?>"><?= $printer['printer_name']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <!-- Model No -->
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Model No</label>
                            <div class="col-lg-6">
                                <!-- <input type="text" name="part_no" class="form-control" placeholder="Enter Model No" required> -->
                                <select name="printer_id" class="form-control" required>
                                    <option value="">Select Model No</option>
                                    <?php while ($model = mysqli_fetch_assoc($result_model)) { ?>
                                        <option value="<?= $model['part_no']; ?>"><?= $model['part_no']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                         <!-- Color -->
                         <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Select Color</label>
                            <div class="col-lg-6">
                                <!-- <input type="text" name="part_no" class="form-control" placeholder="Enter Model No" required> -->
                                <select name="color" class="form-control" required>
                                    <option value="select">Select Color</option>
                                    <option value="black">Black</option>
                                    <option value="white">White</option>
                                    <option value="yellow">Yellow</option>
                                    <option value="magenta">Magenta</option>
                                </select>
                            </div>
                        </div>

                        <!-- Cartridge Number -->
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Cartridge Number</label>
                            <div class="col-lg-6">
                                <input type="text" name="cart_no" class="form-control" placeholder="Enter Cartridge no.." required>
                                
                            </div>
                        </div>


                        <!-- Submit Buttons -->
                        <div class="form-group row">
                            <div class="col-lg-8 ml-auto">
                                <button type="submit" name="submit_cart" class="btn btn-primary">Request</button>
                                <a href="view_request.php" class="btn btn-secondary">Cancel</a>
                            </div>
                        </div>

                    </div>
                </form>
            </div>

        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>
