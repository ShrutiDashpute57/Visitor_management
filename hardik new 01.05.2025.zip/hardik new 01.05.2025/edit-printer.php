<?php
session_start();
include 'include/connection.php';

if (!isset($_SESSION['id']) || empty($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: view-printer.php");
    exit();
}

$printer_id = $_GET['id'];

// Fetch existing printer details
$query = mysqli_query($conn, "SELECT * FROM tbl_printer WHERE id='$printer_id'");
if (mysqli_num_rows($query) == 0) {
    echo "<script>alert('Printer not found!'); window.location.href='view-printer.php';</script>";
    exit();
}
$printer = mysqli_fetch_assoc($query);

// Update printer details
if (isset($_POST['update_printer'])) {
    $printer_name = $_POST['printer_name'];
    $part_no = $_POST['part_no'];

    $update_query = mysqli_query($conn, "UPDATE tbl_printer SET 
        printer_name='$printer_name', 
        part_no='$part_no' 
        WHERE id='$printer_id'");

    if ($update_query) {
        echo "<script>alert('Printer updated successfully.'); window.location.href='view-printer.php';</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
    }
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>
    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Edit Printer</a>
                </li>
            </ol>

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-edit"></i> Edit Printer
                </div>
                <form method="post">
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Brand Name <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="printer_name" class="form-control" value="<?= htmlspecialchars($printer['printer_name']); ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Model Number <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="part_no" class="form-control" value="<?= htmlspecialchars($printer['part_no']); ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-lg-8 ml-auto">
                                <button type="submit" name="update_printer" class="btn btn-primary">Update</button>
                                <a href="view-printer.php" class="btn btn-secondary">Cancel</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>
