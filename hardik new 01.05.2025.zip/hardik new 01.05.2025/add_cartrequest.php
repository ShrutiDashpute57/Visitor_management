<?php
session_start();
include 'include/connection.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Fetch cartridge numbers and departments
$cartridge_result = mysqli_query($conn, "SELECT DISTINCT cart_no FROM tbl_cartridge");
$departments_result = mysqli_query($conn, "SELECT * FROM tbl_department");

/// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_request'])) {
    $cart_no = $_POST['cart_no'];
    $supply_order = $_POST['supply_order'];
    $department = $_POST['department'];
    $officer_name = trim($_POST['officer_name']);
    $officer_designation = trim($_POST['officer_designation']);
    $demand_quantity = (int)$_POST['demand_quantity'];

    // Insert your database query here

    $query = "INSERT INTO tbl_add (cart_no, supply_order, department, officer_name, officer_designation, demand_quantity)
              VALUES ('$cart_no', '$supply_order', '$department', '$officer_name', '$officer_designation', '$demand_quantity')";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Request submitted successfully!'); window.location.href='view_cartrequest.php';</script>";
        exit;
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
    }
}

?>

<?php include('include/header.php'); ?>
<div id="wrapper">
<?php include('include/side-bar.php'); ?>
<div id="content-wrapper">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Request Cartridge</a></li>
        </ol>

        <div class="card mb-3">
            <div class="card-header"><i class="fa fa-edit"></i> Add Cartridge</div>
            <form method="post">
                <div class="form-group row">
                    <label class="col-lg-4 col-form-label">Select Cartridge No</label>
                    <div class="col-lg-6">
                        <select name="cart_no" id="cart_no" class="form-control" required onchange="fetchSupplyOrdersAndQty()">
                            <option value="">--Select--</option>
                            <?php while ($row = mysqli_fetch_assoc($cartridge_result)) { ?>
                                <option value="<?= $row['cart_no'] ?>"><?= $row['cart_no'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-lg-4 col-form-label">Select Supply Order No</label>
                    <div class="col-lg-6">
                        <select name="supply_order" id="supply_order" class="form-control" required></select>
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-lg-4 col-form-label">Select Department</label>
                    <div class="col-lg-6">
                        <select name="department" class="form-control" required>
                            <option value="">--Select--</option>
                            <?php while ($dept = mysqli_fetch_assoc($departments_result)) { ?>
                                <option value="<?= $dept['id'] ?>"><?= $dept['department'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-lg-4 col-form-label">Initiating Officer Name</label>
                    <div class="col-lg-6">
                        <input type="text" name="officer_name" class="form-control" required>
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-lg-4 col-form-label">Designation</label>
                    <div class="col-lg-6">
                        <input type="text" name="officer_designation" class="form-control" required>
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-lg-4 col-form-label">Demand Quantity</label>
                    <div class="col-lg-6">
                        <div class="input-group">
                            <input type="number" name="demand_quantity" class="form-control" required>
                            <div class="input-group-append">
                                <span class="input-group-text">Available: <strong id="available_qty">0</strong></span>
                            </div>
                        </div>
                        <input type="hidden" name="available_quantity" id="available_quantity" value="0">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-lg-8 ml-auto">
                        <button type="submit" name="submit_request" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function fetchSupplyOrdersAndQty() {
    var cartNo = document.getElementById('cart_no').value;

    // Fetch supply orders
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'get_supply_orders.php?cart_no=' + encodeURIComponent(cartNo), true);
    xhr.onload = function () {
        if (this.status == 200) {
            document.getElementById('supply_order').innerHTML = this.responseText;
        }
    };
    xhr.send();

    // Fetch available quantity
    var qtyXhr = new XMLHttpRequest();
    qtyXhr.open('GET', 'get_available_qty.php?cart_no=' + encodeURIComponent(cartNo), true);
    qtyXhr.onload = function () {
        if (this.status == 200) {
            document.getElementById('available_qty').innerText = this.responseText;
            document.getElementById('available_quantity').value = this.responseText;
        }
    };
    qtyXhr.send();
}
</script>

<?php include('include/footer.php'); ?>
