<?php
include 'include/connection.php';

if (isset($_GET['cart_no'])) {
    $cart_no = $_GET['cart_no'];
    $query = "SELECT (quantity) as total_qty FROM tbl_stock WHERE cart_no = '$cart_no'";
    $result = mysqli_query($conn, $query);
    $data = mysqli_fetch_assoc($result);
    echo $data['total_qty'] ?? 0;
}
?>
