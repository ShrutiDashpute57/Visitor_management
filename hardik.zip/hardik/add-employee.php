<?php
session_start();
include 'include/connection.php';

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

// Enable error reporting for debugging
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['sbt-emp'])) {
    $emp_code   = trim($_POST['emp_code']);
    $emp_name   = trim($_POST['emp_name']);
    $designation = trim($_POST['designation']);
    $department  = intval($_POST['department']); // Ensure it's an integer
    $contact_no = trim($_POST['contact_no']);
    $email      = trim($_POST['email']);

    // Validate inputs
    if (empty($emp_code) || empty($emp_name) || empty($designation) || empty($department) || empty($contact_no) || empty($email)) {
        echo "<script>alert('All fields are required!');</script>";
    } else {
        // Prepared statement for security
        $stmt = $conn->prepare("INSERT INTO tbl_employee (emp_code, emp_name, designation, department, contact_no, email) VALUES (?, ?, ?, ?, ?, ?)");

        if ($stmt === false) {
            die("SQL Error: " . $conn->error);
        }

        $stmt->bind_param("sssiis", $emp_code, $emp_name, $designation, $department, $contact_no, $email);

        if ($stmt->execute()) {
            echo "<script>alert('Employee added successfully.'); window.location.href='view-employee.php';</script>";
        } else {
            echo "<script>alert('Error: Unable to add employee.');</script>";
        }

        $stmt->close();
    }
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Add Employee</a>
                </li>
            </ol>

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-user"></i> Employee Details
                </div>       
                <form method="post">
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Employee Code <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="emp_code" class="form-control" placeholder="Enter Employee Code" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Employee Name <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="emp_name" class="form-control" placeholder="Enter Employee Name" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Designation <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="designation" class="form-control" placeholder="Enter Employee Designation" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Department <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <select class="form-control" name="department" required>
                                    <option value="">Select Department</option>
                                    <?php
                                    $dept_query = $conn->query("SELECT id, department FROM tbl_department");
                                    while ($row = $dept_query->fetch_assoc()) {
                                        echo "<option value='" . intval($row['id']) . "'>" . htmlspecialchars($row['department']) . "</option>";
                                    }
                                    ?>
                                </select>
                            </div>    
                        </div>  

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Contact No <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="contact_no" class="form-control" placeholder="Enter Contact No" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Email <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="email" name="email" class="form-control" placeholder="Enter Email" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-lg-8 ml-auto">
                                <button type="submit" name="sbt-emp" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>                    
        </div>
    </div>
</div>  

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>
