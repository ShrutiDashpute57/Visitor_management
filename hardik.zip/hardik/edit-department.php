<?php
session_start();
include 'include/connection.php';

if (!isset($_SESSION['id']) || empty($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: manage-department.php");
    exit();
}

$dept_id = $_GET['id'];

// Fetch existing department details
$query = mysqli_query($conn, "SELECT * FROM tbl_department WHERE id='$dept_id'");
if (mysqli_num_rows($query) == 0) {
    echo "<script>alert('Department not found!'); window.location.href='manage-department.php';</script>";
    exit();
}
$department = mysqli_fetch_assoc($query);

// Update department details
if (isset($_POST['update_department'])) {
    $deptname = $_POST['deptname'];
    $description = $_POST['description'];
    $hod = $_POST['hod'];
    $status = $_POST['status'];

    $update_query = mysqli_query($conn, "UPDATE tbl_department SET 
        department='$deptname', 
        description='$description', 
        hod='$hod', 
        status='$status' 
        WHERE id='$dept_id'");

    if ($update_query) {
        echo "<script>alert('Department updated successfully.'); window.location.href='view-department.php';</script>";
    } else {
        echo "<script>alert('Error: Unable to update department.');</script>";
    }
}

?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">

            <!-- Breadcrumb -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Edit Department</a>
                </li>
            </ol>

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-edit"></i> Edit Department
                </div>

                <form method="post">
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Department Name <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="deptname" class="form-control" value="<?= $department['department']; ?>" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Description <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="description" class="form-control" value="<?= $department['description']; ?>" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">HOD (Employee Code) <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="hod" class="form-control" value="<?= $department['hod']; ?>" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Status <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <select class="form-control" name="status" required>
                                    <option value="1" <?= ($department['status'] == 1) ? 'selected' : ''; ?>>Active</option>
                                    <option value="0" <?= ($department['status'] == 0) ? 'selected' : ''; ?>>Inactive</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-lg-8 ml-auto">
                                <button type="submit" name="update_department" class="btn btn-primary">Update</button>
                                <a href="view-department.php" class="btn btn-secondary">Cancel</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>
