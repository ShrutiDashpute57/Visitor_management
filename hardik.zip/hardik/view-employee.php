<?php
// Start session and include database connection
session_start();
include 'include/connection.php';

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

// Handle delete request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
    if (isset($_POST['delete_id']) && is_numeric($_POST['delete_id'])) {
        $id = $_POST['delete_id'];

        // Prepare delete statement
        $sql = "DELETE FROM tbl_employee WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "i", $id);
            if (mysqli_stmt_execute($stmt)) {
                echo "<script>alert('Employee deleted successfully'); window.location.href='view-employee.php';</script>";
            } else {
                echo "<script>alert('Error deleting employee'); window.location.href='view-employee.php';</script>";
            }
            mysqli_stmt_close($stmt);
        }
    }
}

// Fetch employees with department details
$sql = "SELECT e.id, e.emp_code, e.emp_name, e.designation, e.contact_no, e.email, d.department, e.escort_person_id 
        FROM tbl_employee e
        JOIN tbl_department d ON e.division = d.hod";
$result = mysqli_query($conn, $sql);

// Fetch escort person list
$escortQuery = "SELECT emp_id, emp_name FROM tbl_employee";
$escortResult = mysqli_query($conn, $escortQuery);
$escorts = [];
while ($row = mysqli_fetch_assoc($escortResult)) {
    $escorts[$row['emp_id']] = $row['emp_name'];
}

?>

<?php include('include/header.php'); ?>

<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">View Employees</a>
                </li>
            </ol>

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-users"></i> Employee List
                </div>

                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Employee Code</th>
                                <th>Name</th>
                                <th>Designation</th>
                                <th>Department</th>
                                <th>Contact</th>
                                <th>Email</th>
                                <th>Escort Person</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr>
                                            <td>" . htmlspecialchars($row['emp_id']) . "</td>
                                            <td>" . htmlspecialchars($row['emp_code']) . "</td>
                                            <td>" . htmlspecialchars($row['emp_name']) . "</td>
                                            <td>" . htmlspecialchars($row['designation']) . "</td>
                                            <td>" . htmlspecialchars($row['department']) . "</td>
                                            <td>" . htmlspecialchars($row['contact_no']) . "</td>
                                            <td>" . htmlspecialchars($row['email']) . "</td>
                                            <td>
                                                <form method='POST' action='update-escort.php'>
                                                    <input type='hidden' name='employee_id' value='" . $row['id'] . "'>
                                                    <select name='escort_person' class='form-control' required>
                                                        <option value=''>Select Escort</option>";
                                                        foreach ($escorts as $escort_id => $escort_name) {
                                                            $selected = ($escort_id == $row['escort_person_id']) ? "selected" : "";
                                                            echo "<option value='$escort_id' $selected>$escort_name</option>";
                                                        }
                                                    echo "</select>
                                                    <button type='submit' class='btn btn-primary btn-sm mt-2'>Update</button>
                                                </form>
                                            </td>
                                            <td>
                                                <a href='edit-employee.php?id=" . $row['id'] . "' class='btn btn-warning btn-sm'>Edit</a>
                                                <form method='POST' style='display:inline;'>
                                                    <input type='hidden' name='delete_id' value='" . $row['id'] . "'>
                                                    <button type='submit' name='delete' class='btn btn-danger btn-sm' 
                                                    onclick=\"return confirm('Are you sure you want to delete this employee?');\">
                                                    Delete</button>
                                                </form>
                                            </td>
                                          </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='9' class='text-center'>No employees found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('include/footer.php'); ?>
