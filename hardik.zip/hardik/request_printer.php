<?php
session_start();
include 'include/connection.php';  // Ensure database connection is included

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Fetch Printer List
$query_printers = "SELECT * FROM tbl_printer";
$result_printers = mysqli_query($conn, $query_printers);
if (!$result_printers) {
    die("Query Failed: " . mysqli_error($conn));
}

// Fetch Department List
$query_departments = "SELECT * FROM tbl_department";
$result_departments = mysqli_query($conn, $query_departments);
if (!$result_departments) {
    die("Query Failed: " . mysqli_error($conn));
}

// Generate Demand Number
$year = date("Y");
$query_demand = "SELECT COUNT(*) AS total FROM tbl_request";
$result_demand = mysqli_query($conn, $query_demand);
if (!$result_demand) {
    die("Query Failed: " . mysqli_error($conn));
}
$row_demand = mysqli_fetch_assoc($result_demand);
$demand_no = $year . "/Demand/" . str_pad($row_demand['total'] + 1, 2, '0', STR_PAD_LEFT);

// Handle Form Submission
if (isset($_POST['request_printer'])) {
    $demand_no = $_POST['demand_no'];
    $printer_id = $_POST['printer_id'];
    $part_no = $_POST['part_no'];
    $department_id = $_POST['department_id'];
    $demand_qty = $_POST['demand_qty'];

    // Insert request into the database
    $insert_query = "INSERT INTO tbl_request (demand_no, printer_id, part_no, department_id, demand_qty, status) 
                     VALUES ('$demand_no', '$printer_id', '$part_no', '$department_id', '$demand_qty', 'Pending')";

    if (mysqli_query($conn, $insert_query)) {
        echo "<script>alert('Request submitted successfully.'); window.location.href='view_request.php';</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
    }
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Request Printer</a>
                </li>
            </ol>

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-edit"></i> Request Printer
                </div>

                <form method="post">
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Demand No</label>
                            <div class="col-lg-6">
                                <input type="text" name="demand_no" class="form-control" value="<?= $demand_no; ?>" readonly>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Select Printer</label>
                            <div class="col-lg-6">
                                <select name="printer_id" id="printer" class="form-control" required>
                                    <option value="">Select Printer</option>
                                    <?php while ($printer = mysqli_fetch_assoc($result_printers)) { ?>
                                        <option value="<?= $printer['id']; ?>" 
                                                data-part="<?= $printer['part_no']; ?>"
                                                data-qty="<?= $printer['available_qty']; ?>">
                                            <?= $printer['printer_name']; ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Part No</label>
                            <div class="col-lg-6">
                                <input type="text" name="part_no" id="part_no" class="form-control" readonly>
                            </div>
                        </div>

                        <!-- <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Part No</label>
                            <div class="col-lg-6">
                                <select name="part_no" class="form-control" required>
                                    <option value="">Select Part No</option>
                                    <?php 
                                    mysqli_data_seek($result_printers, 0); // Reset result set pointer
                                    while ($printer = mysqli_fetch_assoc($result_printers)) { ?>
                                        <option value="<?= $printer['part_no']; ?>"><?= $printer['part_no']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div> -->


                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Select Department</label>
                            <div class="col-lg-6">
                                <select name="department_id" class="form-control" required>
                                    <option value="">Select Department</option>
                                    <?php while ($department = mysqli_fetch_assoc($result_departments)) { ?>
                                        <option value="<?= $department['id']; ?>"><?= $department['department']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Available Quantity</label>
                            <div class="col-lg-6">
                                <input type="text" name="available_qty" id="available_qty" class="form-control" readonly>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Demand Quantity</label>
                            <div class="col-lg-6">
                                <input type="number" name="demand_qty" id="demand_qty" class="form-control" min="1" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-lg-8 ml-auto">
                                <button type="submit" name="request_printer" class="btn btn-primary">Request</button>
                                <a href="view_requests.php" class="btn btn-secondary">Cancel</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>

<script>
    document.getElementById('printer').addEventListener('change', function () {
        var selectedOption = this.options[this.selectedIndex];

        document.getElementById('part_no').value = selectedOption.getAttribute('data-part');
        document.getElementById('available_qty').value = selectedOption.getAttribute('data-qty');
    });

    document.getElementById('demand_qty').addEventListener('input', function () {
        var availableQty = parseInt(document.getElementById('available_qty').value) || 0;
        var demandQty = parseInt(this.value) || 0;

        if (demandQty > availableQty) {
            alert('Demand quantity cannot exceed available quantity!');
            this.value = availableQty;
        }
    });
</script>
