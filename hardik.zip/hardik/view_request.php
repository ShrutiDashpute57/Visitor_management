<?php
session_start();
include 'include/connection.php';

$name = $_SESSION['name'];
$id = $_SESSION['id'];

if (empty($id)) {
    header("Location: index.php");
    exit();
}

// DELETE Request
if (isset($_GET['delete'])) {
    $request_id = $_GET['delete'];
    $delete_query = mysqli_query($conn, "DELETE FROM tbl_request WHERE id='$request_id'");

    if ($delete_query) {
        echo "<script>alert('Request deleted successfully.'); window.location.href='view-requests.php';</script>";
    } else {
        echo "<script>alert('Error: Unable to delete request.');</script>";
    }
}

// Handle Status Change (Approve/Reject)
if (isset($_GET['status']) && isset($_GET['id'])) {
    $request_id = $_GET['id'];
    $status = $_GET['status'];

    $update_query = mysqli_query($conn, "UPDATE tbl_request SET status='$status' WHERE id='$request_id'");

    if ($update_query) {
        echo "<script>alert('Request status updated successfully.'); window.location.href='view-requests.php';</script>";
    } else {
        echo "<script>alert('Error: Unable to update request status.');</script>";
    }
}

?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">

            <!-- Breadcrumbs -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Manage Requests</a>
                </li>
            </ol>

            <!-- Request List -->
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-table"></i> Request List
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Demand No</th>
                                    <th>Printer Name</th>
                                    <th>Part Number</th>
                                    <th>Department</th>
                                    <th>Quantity</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 1;
                                $query = mysqli_query($conn, 
                                    "SELECT r.*, p.printer_name, p.part_no, d.department 
                                    FROM tbl_request r
                                    JOIN tbl_printer p ON r.printer_id = p.id
                                    JOIN tbl_department d ON r.department_id = d.id
                                    ORDER BY r.id DESC");

                                while ($row = mysqli_fetch_array($query)) {
                                    echo "<tr>
                                        <td>{$count}</td>
                                        <td>{$row['demand_no']}</td>
                                        <td>{$row['printer_name']}</td>
                                        <td>{$row['part_no']}</td>
                                        <td>{$row['department']}</td>
                                        <td>{$row['demand_qty']}</td>
                                        <td><span class='badge badge-" . ($row['status'] == 'Approved' ? "success" : ($row['status'] == 'Rejected' ? "danger" : "warning")) . "'>{$row['status']}</span></td>
                                        <td>
                                            <a href='view_requests.php?status=Approved&id={$row['id']}' class='btn btn-success btn-sm' onclick=\"return confirm('Approve this request?');\">Approve</a>
                                            <a href='view_requests.php?status=Rejected&id={$row['id']}' class='btn btn-warning btn-sm' onclick=\"return confirm('Reject this request?');\">Reject</a>
                                            <a href='view_requests.php?delete={$row['id']}' class='btn btn-danger btn-sm' onclick=\"return confirm('Are you sure you want to delete?');\">Delete</a>
                                        </td>
                                    </tr>";
                                    $count++;
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>
