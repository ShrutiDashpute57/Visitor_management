
<?php
session_start();
include 'include/connection.php';

$name = $_SESSION['name'];
$id = $_SESSION['id'];

if (empty($id)) {
    header("Location: index.php");
    exit();
}

if (isset($_POST['sbt-printer'])) {
    $printer_name = mysqli_real_escape_string($conn, $_POST['printer_name']);
    $quantity = mysqli_real_escape_string($conn, $_POST['quantity']);
    $part_no = mysqli_real_escape_string($conn, $_POST['part_no']);

    $insert_printer = mysqli_query($conn, "INSERT INTO tbl_printer (printer_name, quantity, part_no) 
                                           VALUES ('$printer_name', '$quantity', '$part_no')");

    if ($insert_printer) {
        echo "<script>alert('Printer added successfully.'); window.location.href='view-printer.php';</script>";
    } else {
        echo "<script>alert('Error: Unable to add printer.');</script>";
    }
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Add Printer</a>
                </li>
            </ol>

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-info-circle"></i> Submit Printer Details
                </div>       
                <form method="post" class="form-valide">
                    <div class="card-body">
                        <!-- Printer Name -->
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Printer Name <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="printer_name" class="form-control" placeholder="Enter Printer Name (e.g., HP, Dell, Canon)" required>
                            </div>
                        </div>

                        <!-- Quantity -->
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Quantity <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="number" name="quantity" class="form-control" placeholder="Enter Quantity" required>
                            </div>
                        </div>

                        <!-- Part Number -->
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Part Number <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="part_no" class="form-control" placeholder="Enter Part Number" required>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="form-group row">
                            <div class="col-lg-8 ml-auto">
                                <button type="submit" name="sbt-printer" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>                   
        </div>
    </div>
</div>  

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>  
