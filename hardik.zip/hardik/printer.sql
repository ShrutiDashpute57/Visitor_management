-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2025 at 04:34 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `printer`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_department`
--

CREATE TABLE `tbl_department` (
  `id` int(11) NOT NULL,
  `department` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `hod` varchar(50) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1=Active, 0=Inactive',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_department`
--

INSERT INTO `tbl_department` (`id`, `department`, `description`, `hod`, `status`, `created_at`) VALUES
(4, 'HRD', 'Human Resource Department', 'EMP123', 1, '2025-02-28 14:47:32'),
(5, 'RAW', 'Raw Material', 'EMP678', 1, '2025-02-26 09:12:57'),
(7, 'NDT', 'NDT', 'EMP945', 1, '2025-02-27 17:00:42'),
(8, 'QC', 'Quality Control', 'EMP345', 1, '2025-02-27 18:04:03'),
(9, 'CSG', 'Computer Section Group', 'EMP892', 1, '2025-02-28 08:54:21'),
(10, 'QA', 'Quality Assurance', 'EMP545', 1, '2025-02-28 14:13:31'),
(11, 'MMD', 'Material Management Division', 'EMP934', 1, '2025-02-28 14:48:17'),
(12, 'Trimming', 'Trimming', 'EMP946', 1, '2025-02-28 16:52:21'),
(13, 'Inhibition', 'Inhibition', 'EMP698', 1, '2025-03-02 09:42:34'),
(15, 'Accounrt', 'Account', 'EMP057', 1, '2025-03-16 12:43:14');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE `tbl_employee` (
  `emp_id` int(11) NOT NULL,
  `emp_code` varchar(50) NOT NULL,
  `emp_name` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `department` int(11) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`emp_id`, `emp_code`, `emp_name`, `designation`, `department`, `contact_no`, `email`, `created_at`) VALUES
(1, '8219', 'Nisha Nandan', 'TO \'B\'', 9, '9685748596', 'nisha@gmail.com', '2025-03-08 13:35:19'),
(2, '8217', 'Saneep Gupta', 'STA \'B\'', 4, '9685748596', 'sandeepgupta@gmail.com', '2025-03-08 13:36:01'),
(3, '8215', 'Vishal Sejwal', 'TO \'A\'', 9, '9687485987', 'vishal@gmail.com', '2025-03-08 13:57:16'),
(6, '8220', 'Nisha Nandan', 'TO \'B\'', 9, '9685748596', 'abc@gmail.com', '2025-03-16 15:32:33');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_printer`
--

CREATE TABLE `tbl_printer` (
  `id` int(11) NOT NULL,
  `printer_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `part_no` varchar(255) NOT NULL,
  `available_qty` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_printer`
--

INSERT INTO `tbl_printer` (`id`, `printer_name`, `quantity`, `part_no`, `available_qty`) VALUES
(1, 'HP', 10, '256AH', 10),
(3, 'Canon', 5, '567AB', 0),
(4, 'HP', 5, '256SD', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_request`
--

CREATE TABLE `tbl_request` (
  `id` int(11) NOT NULL,
  `demand_no` varchar(50) NOT NULL,
  `printer_id` int(11) NOT NULL,
  `part_no` varchar(100) NOT NULL,
  `department_id` int(11) NOT NULL,
  `demand_qty` int(11) NOT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `request_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_request`
--

INSERT INTO `tbl_request` (`id`, `demand_no`, `printer_id`, `part_no`, `department_id`, `demand_qty`, `status`, `request_date`) VALUES
(1, '2025/Demand/01', 1, '256AH', 4, 2, 'Approved', '2025-03-16 14:28:17'),
(2, '2025/Demand/02', 1, '256AH', 9, 2, 'Pending', '2025-03-16 15:21:40'),
(3, '2025/Demand/03', 1, '', 9, 2, 'Pending', '2025-03-16 15:23:56'),
(4, '2025/Demand/04', 1, '', 9, 2, 'Pending', '2025-03-16 15:24:36'),
(5, '2025/Demand/05', 1, '256AH', 8, 2, 'Pending', '2025-03-16 15:28:40');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `emailid` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `user_name`, `emailid`, `password`, `created_at`) VALUES
(1, 'admin', 'admin@gmail.com', '6b8d5de3b53751bac499eb1bef762a2a', '2023-08-26 13:15:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_department`
--
ALTER TABLE `tbl_department`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `hod` (`hod`);

--
-- Indexes for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  ADD PRIMARY KEY (`emp_id`),
  ADD UNIQUE KEY `emp_code` (`emp_code`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `department_id` (`department`);

--
-- Indexes for table `tbl_printer`
--
ALTER TABLE `tbl_printer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_request`
--
ALTER TABLE `tbl_request`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `demand_no` (`demand_no`),
  ADD KEY `printer_id` (`printer_id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_department`
--
ALTER TABLE `tbl_department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_printer`
--
ALTER TABLE `tbl_printer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_request`
--
ALTER TABLE `tbl_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  ADD CONSTRAINT `tbl_employee_ibfk_1` FOREIGN KEY (`department`) REFERENCES `tbl_department` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tbl_request`
--
ALTER TABLE `tbl_request`
  ADD CONSTRAINT `tbl_request_ibfk_1` FOREIGN KEY (`printer_id`) REFERENCES `tbl_printer` (`id`),
  ADD CONSTRAINT `tbl_request_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `tbl_department` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
