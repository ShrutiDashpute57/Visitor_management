<?php
session_start();
include 'include/connection.php';

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

// Fetch employee details if ID is provided
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM tbl_employee WHERE id = '$id'";
    $result = mysqli_query($conn, $query);
    $employee = mysqli_fetch_assoc($result);
}

// Handle form submission
if (isset($_POST['update'])) {
    $emp_code = mysqli_real_escape_string($conn, $_POST['emp_code']);
    $emp_name = mysqli_real_escape_string($conn, $_POST['emp_name']);
    $designation = mysqli_real_escape_string($conn, $_POST['designation']);
    $division = mysqli_real_escape_string($conn, $_POST['division']);
    $contact_no = mysqli_real_escape_string($conn, $_POST['contact_no']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    $update_query = "UPDATE tbl_employee SET 
                     emp_code='$emp_code', 
                     emp_name='$emp_name', 
                     designation='$designation', 
                     division='$division', 
                     contact_no='$contact_no', 
                     email='$email' 
                     WHERE id='$id'";

    if (mysqli_query($conn, $update_query)) {
        echo "<script>alert('Employee updated successfully'); window.location.href='view-employee.php';</script>";
    } else {
        echo "<script>alert('Error updating employee');</script>";
    }
}
?>

<?php include('include/header.php'); ?>

<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Edit Employee</a>
                </li>
            </ol>

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-user"></i> Update Employee Details
                </div>

                <div class="card-body">
                    <form method="post">
                        <div class="form-group">
                            <label>Employee Code</label>
                            <input type="text" name="emp_code" value="<?php echo $employee['emp_code']; ?>" required class="form-control">
                        </div>

                        <div class="form-group">
                            <label>Employee Name</label>
                            <input type="text" name="emp_name" value="<?php echo $employee['emp_name']; ?>" required class="form-control">
                        </div>

                        <div class="form-group">
                            <label>Designation</label>
                            <input type="text" name="designation" value="<?php echo $employee['designation']; ?>" required class="form-control">
                        </div>

                        <div class="form-group">
                            <label>Department</label>
                            <select class="form-control" name="division" required>
                                <option value="">Select Department</option>
                                <?php
                                $dept_query = mysqli_query($conn, "SELECT department, hod FROM tbl_department");
                                while ($row = mysqli_fetch_assoc($dept_query)) {
                                    $selected = ($employee['division'] == $row['hod']) ? "selected" : "";
                                    echo "<option value='" . $row['hod'] . "' $selected>" . $row['department'] . "</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Contact No</label>
                            <input type="text" name="contact_no" value="<?php echo $employee['contact_no']; ?>" required class="form-control">
                        </div>

                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" value="<?php echo $employee['email']; ?>" required class="form-control">
                        </div>

                        <br>
                        <button type="submit" name="update" class="btn btn-primary">Update Employee</button>
                        <a href="view-employee.php" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>                    
        </div>
    </div>
</div>

<?php include('include/footer.php'); ?>
