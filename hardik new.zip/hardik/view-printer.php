<?php
session_start();
include 'include/connection.php';

$name = $_SESSION['name'];
$id = $_SESSION['id'];

if (empty($id)) {
    header("Location: index.php");
    exit();
}

// DELETE Printer
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $delete = mysqli_query($conn, "DELETE FROM tbl_printer WHERE id='$id'");
    if ($delete) {
        echo "<script>alert('Printer deleted successfully.'); window.location.href='view-printer.php';</script>";
    } else {
        echo "<script>alert('Error: Unable to delete printer.'); window.location.href='view-printer.php';</script>";
    }
}

?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">

            <!-- Breadcrumbs -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Manage Printers</a>
                </li>
            </ol>

            <!-- Printer List -->
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-table"></i> Printer List
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Brand Name</th> <!-- changed label -->
                                    <th>Model Number</th> <!-- changed label -->
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 1;
                                $query = mysqli_query($conn, "SELECT * FROM tbl_printer ORDER BY id DESC");
                                while ($row = mysqli_fetch_array($query)) 
                                {
                                    echo "<tr>
                                    <td>{$count}</td>
                                    <td>{$row['printer_name']}</td>
                                    <td>{$row['part_no']}</td>
                                    <td>
                                    <a href='edit-printer.php?id={$row['id']}' class='btn btn-info btn-sm'>Edit</a>
                                    <a href='view-printer.php?delete={$row['id']}' class='btn btn-danger btn-sm' 
                                    onclick=\"return confirm('Are you sure?');\">Delete</a>
                                   </td>
                                   </tr>";
                                    $count++;
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>
