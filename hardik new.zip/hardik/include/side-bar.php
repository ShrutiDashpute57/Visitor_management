<!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: white;">
          <i class="fa fa-list-alt"></i>
          <span>Manage Department</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <a class="dropdown-item" href="add-department.php">Add Department</a>
          <a class="dropdown-item" href="view-department.php">View Department</a>
      </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: white;">
          <i class="fa fa-list-alt"></i>
          <span>Printer</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <a class="dropdown-item" href="add-printer.php">Add Printer</a>
          <a class="dropdown-item" href="view-printer.php">View Printer</a>
      </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="request_printer.php" style="color: white;">
          <i class="fa fa-user"></i>
          <span>Request Printer</span>
        </a>  
      </li>
      <!-- <li class="nav-item">
        <a class="nav-link" href="manage-visitors.php" style="color: white;">
          <i class="fa fa-list-alt"></i>
          <span>Manage Visitors</span>
        </a>
      </li>
      

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: white;">
          <i class="fa fa-list-alt"></i>
          <span>Out Pass</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <a class="dropdown-item" href="create_pass.php">Create Pass</a>
          <a class="dropdown-item" href="manage_pass.php">Manage Pass</a>
      </div>
      </li> -->


      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: white;">
          <i class="fa fa-address-book"></i>
          <span>Manage Employee</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
          <a class="dropdown-item" href="add-employee.php">Add Employee</a>
          <a class="dropdown-item" href="view-employee.php">Manage Employee</a>
      </div>
      </li>


      <li class="nav-item">
        <a class="nav-link" href="logout.php" style="color: white;">
          <i class="fa fa-user"></i>
          <span>Logout</span>
        </a>  
      </li>
     </ul>

     