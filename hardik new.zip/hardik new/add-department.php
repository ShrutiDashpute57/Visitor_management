<?php
session_start();
include 'include/connection.php';

$name = $_SESSION['name'];
$id = $_SESSION['id'];

if (empty($id)) {
    header("Location: index.php");
    exit();
}

if (isset($_POST['sbt-dpt'])) {
    $deptname = mysqli_real_escape_string($conn, $_POST['deptname']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $hod = mysqli_real_escape_string($conn, $_POST['hod']);
    $status = $_POST['status'];

    $insert_department = mysqli_query($conn, "INSERT INTO tbl_department (department, description, hod, status) 
                                              VALUES ('$deptname', '$description', '$hod', '$status')");

    if ($insert_department) {
        echo "<script>alert('Department added successfully.'); window.location.href='view-department.php';</script>";
    } else {
        echo "<script>alert('Error: Unable to add department.');</script>";
    }
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Add Department</a>
                </li>
            </ol>

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-info-circle"></i> Submit Details
                </div>       
                <form method="post" class="form-valide">
                    <div class="card-body">
                        <!-- Department Name -->
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Department Name <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="deptname" class="form-control" placeholder="Enter Department Name" required>
                            </div>
                        </div>

                        <!-- Description (Full Form) -->
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Description (Full Form) <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="description" class="form-control" placeholder="Enter Department Full Form" required>
                            </div>
                        </div>

                        <!-- HOD (Employee Code) -->
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">HOD (Employee Code) <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="hod" class="form-control" placeholder="Enter HOD Employee Code" required>
                            </div>
                        </div>

                        <!-- Status -->
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label">Status <span class="text-danger">*</span></label>
                            <div class="col-lg-6">
                                <select class="form-control" name="status" required>
                                    <option value="">Select Status</option>
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                            </div>    
                        </div>                                                 

                        <!-- Submit Button -->
                        <div class="form-group row">
                            <div class="col-lg-8 ml-auto">
                                <button type="submit" name="sbt-dpt" class="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>                   
        </div>
    </div>
</div>  

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>
