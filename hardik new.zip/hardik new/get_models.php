<?php
include 'include/connection.php';

if (isset($_POST['brand_name'])) {
    $brand_name = $_POST['brand_name'];

    $query = "SELECT part_no FROM tbl_printer WHERE printer_name = '$brand_name'";
    $result = mysqli_query($conn, $query);

    echo '<option value="">Select Model No</option>';
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<option value="'.$row['part_no'].'">'.$row['part_no'].'</option>';
    }
}
?>
