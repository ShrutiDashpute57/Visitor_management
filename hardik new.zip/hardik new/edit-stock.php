<?php
session_start();
include 'include/connection.php';

$name = $_SESSION['name'];
$id = $_SESSION['id'];

if (empty($id)) {
    header("Location: index.php");
    exit();
}

$edit_id = $_GET['id'] ?? '';

if (empty($edit_id)) {
    echo "<script>alert('Invalid Request!'); window.location.href='view-stock.php';</script>";
    exit();
}

// Fetch stock details
$query = mysqli_query($conn, "SELECT * FROM tbl_stock WHERE id='$edit_id'");
$row = mysqli_fetch_assoc($query);

if (!$row) {
    echo "<script>alert('No stock record found.'); window.location.href='view-stock.php';</script>";
    exit();
}

// Update stock details
if (isset($_POST['update'])) {
    $printer_name = $_POST['printer_name'];
    $part_no = $_POST['part_no'];
    $cart_no = $_POST['cart_no'];
    $supply_order = $_POST['supply_order'];
    $order_date = $_POST['order_date'];
    $quantity = $_POST['quantity'];
    $received_date = $_POST['received_date'];

    $update = mysqli_query($conn, "UPDATE tbl_stock SET 
        printer_name='$printer_name', 
        part_no='$part_no', 
        cart_no='$cart_no', 
        supply_order='$supply_order',
        order_date='$order_date',
        quantity='$quantity',
        received_date='$received_date'
        WHERE id='$edit_id'");

    if ($update) {
        echo "<script>alert('Stock record updated successfully.'); window.location.href='view-stock.php';</script>";
    } else {
        echo "<script>alert('Error: Unable to update stock record.'); window.location.href='edit-stock.php?id=$edit_id';</script>";
    }
}
?>

<?php include('include/header.php'); ?>
<div id="wrapper">
    <?php include('include/side-bar.php'); ?>

    <div id="content-wrapper">
        <div class="container-fluid">

            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="view-stock.php">Manage Stock</a>
                </li>
                <li class="breadcrumb-item active">Edit Stock</li>
            </ol>

            <!-- Edit Stock Form -->
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-edit"></i> Edit Stock
                </div>
                <div class="card-body">
                    <form method="post">

                        <div class="form-group">
                            <label>Brand Name</label>
                            <input type="text" name="printer_name" class="form-control" required value="<?php echo htmlspecialchars($row['printer_name']); ?>">
                        </div>

                        <div class="form-group">
                            <label>Model Number</label>
                            <input type="text" name="part_no" class="form-control" required value="<?php echo htmlspecialchars($row['part_no']); ?>">
                        </div>

                        <div class="form-group">
                            <label>Cartridge No</label>
                            <input type="text" name="cart_no" class="form-control" required value="<?php echo htmlspecialchars($row['cart_no']); ?>">
                        </div>

                        <div class="form-group">
                            <label>Supplymentory Order No</label>
                            <input type="text" name="supply_order" class="form-control" required value="<?php echo htmlspecialchars($row['supply_order']); ?>">
                        </div>

                        <div class="form-group">
                            <label>Order Date</label>
                            <input type="date" name="order_date" class="form-control" required value="<?php echo htmlspecialchars($row['order_date']); ?>">
                        </div>

                        <div class="form-group">
                            <label>Quantity</label>
                            <input type="number" name="quantity" class="form-control" required value="<?php echo htmlspecialchars($row['quantity']); ?>">
                        </div>

                        <div class="form-group">
                            <label>Material Received Date</label>
                            <input type="date" name="received_date" class="form-control" required value="<?php echo htmlspecialchars($row['received_date']); ?>">
                        </div>

                        <button type="submit" name="update" class="btn btn-primary">Update</button>
                        <a href="view-stock.php" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php include('include/footer.php'); ?>
